#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

# Set to true to reinstall packages even if already installed (useful for fixing broken installs)
FORCE_REINSTALL=false

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
        ;;

    dnf)
        ;;

    apt)
        # BUG FIX: 'inst wine' was here BEFORE i386 arch is added in OS section.
        # On Ubuntu/Debian, wine needs i386 first. Wine is now installed in OS
        # Specific Tasks after dpkg --add-architecture i386 + apt update.
        # 'inst wine' in Custom Code below handles any other apt-based distros.
        inst wine-desktop-files
        inst exe-thumbnailer
        inst wine-binfmt
        inst binfmt-support
        inst wine-mono
        inst wine-gecko

        echo "Marking all installed packages as 'Manual' to prevent accidental removal..."
        sudo apt-mark manual $(apt-mark showauto) > /dev/null 2>&1
        echo "System is now locked. No packages will be autoremoved."
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        ;;

    zypper)
        ;;

    yum)
        ;;

    emerge)
        ;;

    eopkg)
        ;;

    apk)
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu|zorin|regataos)
        # BUG FIX: i386 must be added before wine is installed.
        # 'inst wine' is now here (after i386 + apt update) not in the PM section.
        sudo dpkg --add-architecture i386
        sudo apt -qq update -y
        inst wine
        echo "Marking all installed packages as 'Manual' to prevent accidental removal..."
        sudo apt-mark manual $(apt-mark showauto) > /dev/null 2>&1
        echo "System is now locked. No packages will be autoremoved."
        ;;

    debian|pop|deepin)
        sudo dpkg --add-architecture i386 && sudo apt update
        inst wine
        echo "Marking all installed packages as 'Manual' to prevent accidental removal..."
        sudo apt-mark manual $(apt-mark showauto) > /dev/null 2>&1
        echo "System is now locked. No packages will be autoremoved."
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed)
        zypper --non-interactive --quiet addrepo -C https://download.opensuse.org/repositories/Emulators:Wine/openSUSE_Tumbleweed/Emulators:Wine.repo
        zypper --non-interactive refresh
        inst wine
        inst wine-32bit
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        # Wine on Arch includes WoW64 (32-bit support built-in since Wine 8)
        ;;

    argent|biglinux|cachyos|garuda)
        # Arch-based - WoW64 built-in, no separate wine32 package needed
        ;;

    solus)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # rpm-ostree via inst() for packages; require reboot to activate.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------
inst wine
# winetricks and protontricks are not available via rpm-ostree on immutable OS
if ! [ "$IMMUTABLE_OS" = "true" ]; then
    inst winetricks
    inst protontricks
fi

# Extract overlay - behaviour differs between normal and immutable OS:
#   Normal OS : /usr/share is writable, extract everything to /
#   Immutable  : /usr/share is read-only; extract only opt/LastOS (writable),
#                skip usr/ entirely, and save Overlay.tar + Scripts-Wine to
#                $HOME/.lltemp2/ so the deferred wineboot autostart can use
#                them after reboot (reboot wipes /tmp, .lltemp2 survives).
if [ "$IMMUTABLE_OS" = "true" ]; then
    echo "Immutable OS: extracting opt/LastOS only (skipping /usr/share - read-only)..."
    sudo tar -xvf Overlay.tar -C / --no-same-owner \
        --exclude='usr' --exclude='./usr' \
        --exclude='etc/xdg' --exclude='./etc/xdg' \
        2>/dev/null || true

    # Stage Overlay.tar and Scripts-Wine into $HOME/.lltemp2/ so they survive reboot.
    # /tmp is cleared on reboot; .lltemp2 in the user home persists until cleaned up.
    LLTEMP="$HOME/.lltemp2"
    mkdir -p "$LLTEMP"
    chmod 777 "$LLTEMP"
    echo "Staging Overlay.tar to $LLTEMP for post-reboot icon/desktop install..."
    cp Overlay.tar "$LLTEMP/Overlay.tar"
    echo "Staging Scripts-Wine for post-reboot wineboot..."
    mkdir -p "$LLTEMP/Scripts-Wine"
    chmod 777 "$LLTEMP/Scripts-Wine"
    # BUG FIX: path was '/opt/LastOS/Scripts-Wine' (leading slash) which never
    # matched archive members stored as 'opt/LastOS/Scripts-Wine' (no slash).
    # Silently failed due to 2>/dev/null, leaving Scripts-Wine empty after reboot.
    tar -xf Overlay.tar -C "$LLTEMP" opt/LastOS/Scripts-Wine --strip-components=2 --no-same-owner 2>/dev/null || true
else
    echo "Extracting overlay to /..."
    sudo tar -xvf Overlay.tar -C / --no-same-owner
fi

exit 0