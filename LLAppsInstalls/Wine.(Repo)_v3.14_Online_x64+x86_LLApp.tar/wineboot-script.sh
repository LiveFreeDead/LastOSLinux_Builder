#!/bin/bash
# LLStore post-reboot Wine initialisation.
# Copied to $HOME/.lltemp2/ at install time, runs once after first login
# following a Wine rpm-ostree install/reboot, then removes itself.

WINE_CACHE="$HOME/.cache/wine"
LLTEMP="$HOME/.lltemp2"
AUTOSTART_FILE="$HOME/.config/autostart/llstore-wineboot.desktop"

# 1. Initialise Wine prefix
echo "Initialising Wine prefix..."
wine wineboot

# 2. Install Mono and Gecko (downloaded before reboot by LLScript.sh)
echo "Installing Wine Mono..."
wine "$WINE_CACHE/wine-mono-11.0.0-x86.msi"

echo "Installing Wine Gecko (x86)..."
wine "$WINE_CACHE/wine-gecko-2.47.4-x86.msi"

echo "Installing Wine Gecko (x86_64)..."
wine "$WINE_CACHE/wine-gecko-2.47.4-x86_64.msi"

# 3. Fonts and registry tweaks (staged to .lltemp2 by LLScript_Sudo.sh)
SCRIPTS_WINE="$LLTEMP/Scripts-Wine"
if [ -f "$SCRIPTS_WINE/Fonts.exe" ]; then
    echo "Installing Fonts..."
    wine "$SCRIPTS_WINE/Fonts.exe"
fi
if [ -f "$SCRIPTS_WINE/LastOS-Tweaks.reg" ]; then
    echo "Applying registry tweaks..."
    wine regedit /s "$SCRIPTS_WINE/LastOS-Tweaks.reg"
fi

# 4. Extract Overlay.tar - redirect to user-level paths (immutable OS, /usr/share read-only)
#    usr/share/icons/        -> ~/.local/share/icons/
#    usr/share/applications/ -> ~/.local/share/applications/
OVERLAY_TAR="$LLTEMP/Overlay.tar"
if [ -f "$OVERLAY_TAR" ]; then
    echo "Installing Wine icons to ~/.local/share/icons/..."
    ICONS_TMP=$(mktemp -d)
    tar -xf "$OVERLAY_TAR" -C "$ICONS_TMP" usr/share/icons 2>/dev/null || true
    if [ -d "$ICONS_TMP/usr/share/icons" ]; then
        mkdir -p "$HOME/.local/share/icons"
        cp -r "$ICONS_TMP/usr/share/icons/." "$HOME/.local/share/icons/"
        command -v update-icon-caches >/dev/null 2>&1 && \
            update-icon-caches "$HOME/.local/share/icons"/* >/dev/null 2>&1 || true
    fi
    rm -rf "$ICONS_TMP"

    echo "Installing Wine .desktop files to ~/.local/share/applications/..."
    APPS_TMP=$(mktemp -d)
    tar -xf "$OVERLAY_TAR" -C "$APPS_TMP" usr/share/applications 2>/dev/null || true
    if [ -d "$APPS_TMP/usr/share/applications" ]; then
        mkdir -p "$HOME/.local/share/applications"
        cp -r "$APPS_TMP/usr/share/applications/." "$HOME/.local/share/applications/"
        update-desktop-database "$HOME/.local/share/applications" >/dev/null 2>&1 || true
    fi
    rm -rf "$APPS_TMP"

    echo "Overlay install complete."
fi

# 5. Add Wine C drive bookmark
grep -qF "/.wine/drive_c" ~/.config/gtk-3.0/bookmarks 2>/dev/null || \
    echo "file://$HOME/.wine/drive_c C:\\ (Wine)" >> ~/.config/gtk-3.0/bookmarks

# 6. Self-clean: remove autostart then wipe .lltemp2
rm -f "$AUTOSTART_FILE"
rm -rf "$LLTEMP"

echo "Wine post-reboot setup complete."
