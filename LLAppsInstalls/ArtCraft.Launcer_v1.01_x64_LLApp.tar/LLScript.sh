#!/bin/bash

#LLStore Script v1.02

#---------- User Set Variables ----------

# (Add any variables your script needs here before the core loads)

# ArtCraft Launcher installer settings
AC_REPO="storytold/craft-launcher"             # Official ArtCraft Launcher GitHub repo
AC_FALLBACK_VER="0.8.1"                        # Only used if the latest version can't be looked up
AC_APP_ID="ai.storyteller.artcraft-launcher"   # Menu-entry / icon name the launcher itself uses
AC_FORCE_APPIMAGE="${AC_FORCE_APPIMAGE:-1}"    # Set to 1 to skip distro packages and use the AppImage
AC_PKG_FORMAT=""                               # deb / rpm / arch / appimage - set per distro below

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

# Source shared core: functions (flatinst), terminal/OS detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Core.sh" ]; then source "%ToolPath%/LLScript_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- OS Specific Tasks ----------
# Fallback if the core didn't provide $ID (e.g. script run by hand without LLScript_Core.sh)
[ -z "$ID" ] && ID=$( . /etc/os-release 2>/dev/null || . /usr/lib/os-release 2>/dev/null; echo "$ID" )

# Each distro picks the package type the ArtCraft Launcher is installed from.
# Anything not listed is detected automatically from ID_LIKE / the package manager.
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
case "$ID" in
    manjaro)
        AC_PKG_FORMAT="arch"
        ;;

    linuxmint|ubuntu)
        AC_PKG_FORMAT="deb"
        ;;

    debian|pop)
        AC_PKG_FORMAT="deb"
        ;;

    fedora|nobara)
        AC_PKG_FORMAT="rpm"
        ;;

    opensuse-tumbleweed|opensuse-leap)
        AC_PKG_FORMAT="rpm"
        ;;

    almalinux)
        AC_PKG_FORMAT="rpm"
        ;;

    arch|endeavouros)
        AC_PKG_FORMAT="arch"
        ;;

    argent)
        AC_PKG_FORMAT=""   # auto-detect
        ;;

    biglinux)
        AC_PKG_FORMAT="arch"
        ;;

    cachyos)
        AC_PKG_FORMAT="arch"
        ;;

    deepin)
        AC_PKG_FORMAT="deb"
        ;;

    garuda)
        AC_PKG_FORMAT="arch"
        ;;

    regataos)
        AC_PKG_FORMAT="rpm"
        ;;

    solus)
        AC_PKG_FORMAT="appimage"   # eopkg - no native package, use the AppImage
        ;;

    zorin)
        AC_PKG_FORMAT="deb"
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use $HOME/.local/share/ paths instead of /usr/share/, and note that
        # rpm-ostree installs require a reboot before packages are available.
        AC_PKG_FORMAT="appimage"   # per-user AppImage, no reboot needed
        ;;

    *)
        echo "Unknown Distribution ($ID). Package type will be auto-detected"
        AC_PKG_FORMAT=""
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$XDG_SESSION_DESKTOP" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($XDG_SESSION_DESKTOP). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# To install user Flatpaks (no sudo required):
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

# =============================================================================
#  ArtCraft Launcher - download, install and add to the Applications menu
#
#  Official source : https://github.com/storytold/craft-launcher (latest release)
#  How it installs : 1) the distro's own package (.deb / .rpm / Arch .pkg.tar.zst)
#                       -> installs /usr/bin/artcraft-launcher + the menu entry
#                    2) otherwise (or if 1 fails / no root / immutable OS) the
#                       portable AppImage -> ~/Applications + a menu entry in
#                       ~/.local/share/applications (no root needed)
#  Every download is checked against the release's SHA256SUMS.txt first.
#
#  Optional: run with AC_FORCE_APPIMAGE=1 to skip distro packages.
# =============================================================================

ac_have() { command -v "$1" >/dev/null 2>&1; }
ac_say()  { echo -e "  $*"; }
ac_warn() { echo -e "  \033[33m!\033[0m $*" >&2; }
ac_err()  { echo -e "  \033[31mERROR:\033[0m $*" >&2; }

# ---- Who are we installing for? (LLStore may run this through sudo/pkexec) ----
ac_resolve_user() {
    AC_UID_NOW=$(id -u)
    if [ "$AC_UID_NOW" -eq 0 ]; then
        AC_USER="${SUDO_USER:-}"
        if [ -z "$AC_USER" ] && [ -n "${PKEXEC_UID:-}" ]; then AC_USER=$(id -nu "$PKEXEC_UID" 2>/dev/null); fi
        [ -z "$AC_USER" ] && AC_USER="root"
        AC_SUDO=""
    else
        AC_USER=$(id -un)
        if ac_have sudo; then AC_SUDO="sudo"; else AC_SUDO="none"; fi
    fi
    AC_HOME=$(getent passwd "$AC_USER" 2>/dev/null | cut -d: -f6)
    [ -z "$AC_HOME" ] && AC_HOME="$HOME"
    if [ "$AC_USER" = "$(id -un)" ] && [ -n "${XDG_DATA_HOME:-}" ]; then
        AC_DATA="$XDG_DATA_HOME"
    else
        AC_DATA="$AC_HOME/.local/share"
    fi
}

# Run a command as the real user (needed when the script itself is running as root)
ac_as_user() {
    if [ "$AC_UID_NOW" -eq 0 ] && [ "$AC_USER" != "root" ]; then
        if   ac_have runuser; then runuser -u "$AC_USER" -- "$@"
        elif ac_have sudo;    then sudo -u "$AC_USER" "$@"
        else su -s /bin/bash "$AC_USER" -c "$(printf '%q ' "$@")"
        fi
    else
        "$@"
    fi
}

ac_id_like() { ( . /etc/os-release 2>/dev/null || . /usr/lib/os-release 2>/dev/null; echo "$ID_LIKE" ); }

# ---- Pick the package format when the OS case-list above didn't decide ----
ac_autodetect_format() {
    local like=" $ID $(ac_id_like) "
    case "$like" in
        *" arch "*|*" manjaro "*|*" archlinux "*)                                   AC_PKG_FORMAT="arch"; return ;;
        *" debian "*|*" ubuntu "*)                                                  AC_PKG_FORMAT="deb";  return ;;
        *" fedora "*|*" rhel "*|*" centos "*|*" suse "*|*" opensuse "*)             AC_PKG_FORMAT="rpm";  return ;;
    esac
    if   ac_have apt-get; then AC_PKG_FORMAT="deb"
    elif ac_have dnf || ac_have zypper || ac_have yum; then AC_PKG_FORMAT="rpm"
    elif ac_have pacman;  then AC_PKG_FORMAT="arch"
    else AC_PKG_FORMAT="appimage"
    fi
}

ac_detect_arch() {
    case "$(uname -m)" in
        x86_64|amd64)  AC_ARCH="x86_64"  ;;
        aarch64|arm64) AC_ARCH="aarch64" ;;
        riscv64)       AC_ARCH="riscv64" ;;
        *)             AC_ARCH=""        ;;
    esac
}

# ---- Downloading ----
ac_get() { # ac_get URL OUTFILE
    if ac_have curl; then
        local prog="-sS"; [ -t 1 ] && prog="--progress-bar"
        curl -fL $prog --retry 3 --retry-delay 2 --connect-timeout 20 -o "$2" "$1"
    elif ac_have wget; then
        wget -q --tries=3 --timeout=20 -O "$2" "$1"
    else
        return 127
    fi
}

# Newest release version, read from the github.com redirect (no API rate limit)
ac_latest_version() {
    local url=""
    if ac_have curl; then
        url=$(curl -fsSIL --connect-timeout 20 -o /dev/null -w '%{url_effective}' "https://github.com/$AC_REPO/releases/latest" 2>/dev/null)
    elif ac_have wget; then
        url=$(wget -q --spider --server-response "https://github.com/$AC_REPO/releases/latest" 2>&1 | awk '/^[[:space:]]*[Ll]ocation:/ {print $2}' | tail -n1 | tr -d '\r')
    fi
    case "$url" in
        */releases/tag/v*) echo "${url##*/tag/v}" ;;
        */releases/tag/*)  echo "${url##*/tag/}"  ;;
    esac
}

ac_fetch_verified() { # ac_fetch_verified FILENAME -> $AC_TMP/FILENAME, checked against SHA256SUMS.txt
    local f="$1" want have
    ac_say "Downloading $f ..."
    if ! ac_get "$AC_BASE/$f" "$AC_TMP/$f"; then ac_warn "Download failed: $f"; return 1; fi
    want=$(awk -v f="$f" '$2==f || $2=="*" f {print $1}' "$AC_TMP/SHA256SUMS.txt" | head -n1)
    if [ -z "$want" ]; then ac_warn "No checksum is published for $f"; rm -f "$AC_TMP/$f"; return 1; fi
    have=$(sha256sum "$AC_TMP/$f" | awk '{print $1}')
    if [ "$want" != "$have" ]; then ac_warn "Checksum mismatch for $f - not installing it"; rm -f "$AC_TMP/$f"; return 1; fi
    ac_say "Checksum verified."
}

# ---- Menu entry (.desktop file in the user's Applications menu) ----
ac_write_desktop() { # ac_write_desktop EXEC_LINE TRYEXEC ICON [APPIMAGE_VERSION]
    local d="$AC_DATA/applications" out="$AC_TMP/$AC_APP_ID.desktop"
    {
        echo "[Desktop Entry]"
        echo "Type=Application"
        echo "Name=ArtCraft Launcher"
        echo "GenericName=Craft App Suite Launcher"
        echo "Comment=Install, update and launch the Craft App Suite (PhotoCraft, FilmCraft, WordCraft...)"
        echo "Exec=$1"
        echo "TryExec=$2"
        echo "Icon=$3"
        echo "Terminal=false"
        echo "StartupNotify=true"
        echo "StartupWMClass=artcraft-launcher"
        echo "Categories=Graphics;Utility;"
        echo "Keywords=artcraft;craft;launcher;photocraft;filmcraft;wordcraft;gridcraft;deckcraft;"
        [ -n "$4" ] && echo "X-AppImage-Version=$4"
    } > "$out"
    ac_as_user mkdir -p "$d" && ac_as_user install -m 644 "$out" "$d/$AC_APP_ID.desktop"
}

ac_refresh_menus() {
    local d="$AC_DATA"
    if ac_have update-desktop-database; then ac_as_user update-desktop-database "$d/applications" >/dev/null 2>&1; fi
    if ac_have gtk-update-icon-cache && [ -f "$d/icons/hicolor/index.theme" ]; then
        ac_as_user gtk-update-icon-cache -q -t -f "$d/icons/hicolor" >/dev/null 2>&1
    fi
    if   ac_have kbuildsycoca6; then ac_as_user kbuildsycoca6 --noincremental >/dev/null 2>&1
    elif ac_have kbuildsycoca5; then ac_as_user kbuildsycoca5 --noincremental >/dev/null 2>&1
    fi
    return 0
}

# ---- Method 1: the distro's native package ----
ac_install_native() {
    local f=""
    case "$AC_PKG_FORMAT" in
        deb)  ac_have apt-get || return 1
              f="artcraft-launcher-$AC_VER-linux-$AC_ARCH.deb" ;;
        rpm)  { ac_have dnf || ac_have zypper || ac_have yum; } || return 1
              f="artcraft-launcher-$AC_VER-linux-$AC_ARCH.rpm" ;;
        arch) ac_have pacman || return 1
              f="artcraft-launcher-$AC_VER-linux-$AC_ARCH.pkg.tar.zst" ;;
        *)    return 1 ;;
    esac
    if [ "$AC_SUDO" = "none" ]; then ac_warn "Not root and sudo is not installed - can't install a system package."; return 1; fi
    ac_fetch_verified "$f" || return 1

    ac_say "Installing the $AC_PKG_FORMAT package (you may be asked for your password) ..."
    case "$AC_PKG_FORMAT" in
        deb)  $AC_SUDO apt-get update -qq >/dev/null 2>&1
              $AC_SUDO apt-get install -y "$AC_TMP/$f" || return 1 ;;
        rpm)  if   ac_have dnf;    then $AC_SUDO dnf install -y "$AC_TMP/$f" || return 1
              elif ac_have zypper; then $AC_SUDO zypper --non-interactive --no-gpg-checks install "$AC_TMP/$f" || return 1
              else                      $AC_SUDO yum install -y "$AC_TMP/$f" || return 1
              fi ;;
        arch) $AC_SUDO pacman -U --noconfirm "$AC_TMP/$f" || return 1 ;;
    esac

    [ -x /usr/bin/artcraft-launcher ] || ac_have artcraft-launcher || return 1

    # The package ships its own menu entry; add one for the user only if it is missing.
    if [ ! -f "/usr/share/applications/$AC_APP_ID.desktop" ]; then
        ac_warn "Package has no menu entry - adding one for $AC_USER."
        local ic="applications-graphics"
        ls /usr/share/icons/hicolor/*/apps/"$AC_APP_ID".* >/dev/null 2>&1 && ic="$AC_APP_ID"
        ac_write_desktop "artcraft-launcher" "artcraft-launcher" "$ic" "" || return 1
    fi
    AC_METHOD="system package ($AC_PKG_FORMAT)"
    AC_LAUNCH_HINT="artcraft-launcher"
    return 0
}

# ---- Method 2: portable AppImage (any distro, no root, works on immutable OSes) ----
ac_install_appimage() {
    if [ "$AC_ARCH" = "riscv64" ]; then ac_warn "No AppImage is published for riscv64."; return 1; fi
    local f="artcraft-launcher-$AC_VER-linux-$AC_ARCH.AppImage"
    local appdir="$AC_HOME/Applications" target="$AC_HOME/Applications/artcraft-launcher.AppImage"
    local icondir="$AC_DATA/icons/hicolor/256x256/apps"
    ac_fetch_verified "$f" || return 1

    ac_as_user mkdir -p "$appdir" "$icondir" "$AC_DATA/applications" || { ac_err "Can't create folders in $AC_HOME"; return 1; }
    ac_as_user install -m 755 "$AC_TMP/$f" "$target" || { ac_err "Can't write $target"; return 1; }

    # Pull the real icon out of the AppImage (this extraction does not need FUSE)
    local icon="applications-graphics"
    ( cd "$AC_TMP" && "$target" --appimage-extract "$AC_APP_ID.png" >/dev/null 2>&1 )
    if [ -f "$AC_TMP/squashfs-root/$AC_APP_ID.png" ] && ac_as_user install -m 644 "$AC_TMP/squashfs-root/$AC_APP_ID.png" "$icondir/$AC_APP_ID.png"; then
        icon="$AC_APP_ID"
    fi

    # Many distros (Ubuntu 22.04+, Fedora, Mint 22...) no longer ship libfuse2, so run
    # the AppImage in extract-and-run mode whenever it is missing.
    local prefix=""
    if ! { ldconfig -p 2>/dev/null || /sbin/ldconfig -p 2>/dev/null; } | grep -q 'libfuse\.so\.2'; then
        prefix="env APPIMAGE_EXTRACT_AND_RUN=1 "
    fi
    ac_write_desktop "${prefix}\"$target\"" "$target" "$icon" "$AC_VER" || { ac_err "Can't create the menu entry"; return 1; }
    AC_METHOD="portable AppImage ($target)"
    AC_LAUNCH_HINT="\"$target\""
    return 0
}

ac_installed_version() {
    local v=""
    if ac_have artcraft-launcher; then v=$(timeout 10 artcraft-launcher --version 2>/dev/null | awk '{print $NF}' | head -n1); fi
    if [ -z "$v" ] && [ -f "$AC_DATA/applications/$AC_APP_ID.desktop" ]; then
        v=$(sed -n 's/^X-AppImage-Version=//p' "$AC_DATA/applications/$AC_APP_ID.desktop" | head -n1)
    fi
    echo "$v"
}

ac_menu_entry_exists() {
    [ -f "/usr/share/applications/$AC_APP_ID.desktop" ] || [ -f "$AC_DATA/applications/$AC_APP_ID.desktop" ]
}

ac_run() {
    ac_resolve_user
    ac_detect_arch
    [ -z "${AC_PKG_FORMAT:-}" ] && ac_autodetect_format

    if [ -z "$AC_ARCH" ]; then ac_err "Unsupported CPU ($(uname -m)). ArtCraft Launcher is built for x86_64, aarch64 and riscv64."; return 1; fi
    if ! ac_have curl && ! ac_have wget; then ac_err "Neither curl nor wget is installed - install one of them and run again."; return 1; fi

    # The launcher needs glibc 2.35+ (Ubuntu 22.04, Mint 21, Debian 12, Fedora 36 or newer)
    local glibc; glibc=$(getconf GNU_LIBC_VERSION 2>/dev/null | awk '{print $2}')
    if [ -n "$glibc" ] && [ "$(printf '%s\n2.35\n' "$glibc" | sort -V | head -n1)" != "2.35" ]; then
        ac_err "This system has glibc $glibc; ArtCraft Launcher needs 2.35 or newer (Ubuntu 22.04 / Mint 21 / Debian 12 / Fedora 36 or later)."
        return 1
    fi

    ac_say "System: ${PRETTY_NAME:-$ID} | CPU: $AC_ARCH | Package type: $AC_PKG_FORMAT | User: $AC_USER"

    AC_VER=$(ac_latest_version)
    if [ -z "$AC_VER" ]; then ac_warn "Couldn't look up the latest version - using v$AC_FALLBACK_VER."; AC_VER="$AC_FALLBACK_VER"; fi
    AC_BASE="https://github.com/$AC_REPO/releases/download/v$AC_VER"
    ac_say "Latest ArtCraft Launcher: v$AC_VER"

    local have; have=$(ac_installed_version)
    if [ "$have" = "$AC_VER" ] && ac_menu_entry_exists && [ "${AC_REINSTALL:-0}" != "1" ]; then
        ac_say "ArtCraft Launcher v$AC_VER is already installed and in the Applications menu. Nothing to do."
        ac_refresh_menus
        return 0
    fi

    ac_get "$AC_BASE/SHA256SUMS.txt" "$AC_TMP/SHA256SUMS.txt" || { ac_err "Couldn't download SHA256SUMS.txt - refusing to install an unverified file."; return 1; }

    local ok=0
    local immutable=false
    { [ "${IMMUTABLE_OS:-}" = "true" ] || [ -e /run/ostree-booted ]; } && immutable=true

    if [ "$AC_FORCE_APPIMAGE" != "1" ] && [ "$immutable" = "false" ] && [ "$AC_PKG_FORMAT" != "appimage" ]; then
        if ac_install_native; then ok=1; else ac_warn "System package install didn't complete - trying the portable AppImage instead."; fi
    fi
    if [ "$ok" -eq 0 ]; then
        if ac_install_appimage; then ok=1; fi
    fi
    if [ "$ok" -eq 0 ]; then ac_err "ArtCraft Launcher could not be installed."; return 1; fi

    ac_refresh_menus
    echo
    ac_say "\033[32mDone!\033[0m ArtCraft Launcher v$AC_VER installed as $AC_METHOD."
    ac_say "Find it in your Applications menu under \"ArtCraft Launcher\" (Graphics / Utilities),"
    ac_say "or type: ${AC_LAUNCH_HINT:-artcraft-launcher}. If it isn't listed straight away, log out and back in."
    return 0
}

artcraft_main() {
    AC_TMP=$(mktemp -d 2>/dev/null) || { ac_err "Can't create a temporary folder."; return 1; }
    chmod 755 "$AC_TMP"
    ac_run
    local rc=$?
    rm -rf "$AC_TMP"
    return $rc
}

artcraft_main
exit $?