#!/bin/bash

#LLStore Sudo Script v1.04

#---------- User Set Variables ----------

# Set to true to reinstall packages even if already installed (useful for fixing broken installs)
FORCE_REINSTALL=false

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
        ;;

    dnf)
        ;;

    apt)
        # BUG FIX: Removed 'inst wine' (distro repo wine conflicts with winehq-stable).
        # BUG FIX: Removed wine-mono/wine-gecko (installed as MSI files by LLScript.sh).
        # BUG FIX: Removed wine-binfmt — it hard-depends on Ubuntu's 'wine' package,
        #          pulling Ubuntu wine back in after the purge and blocking WineHQ install.
        #          binfmt_misc is registered manually in the OS section after WineHQ installs.
        # winehq-stable is installed per-distro in OS Specific Tasks below.
        # BUG FIX: wine-desktop-files removed from here — purge "wine*" below matches it
        # (glob catches the "wine" prefix) and immediately uninstalls it. It is
        # reinstalled alongside wine-stable in the OS Specific Tasks section below.
        inst exe-thumbnailer
        inst binfmt-support

        # Script to remove system-wide Wine while keeping Steam & 32-bit game libraries

        echo "Removing system-wide Wine packages..."
        # Purge wine-related packages across both architectures
        sudo apt-get purge "wine*" "wine32:i386" "wine64" "libwine*" libwine:i386 fonts-wine -y 2>/dev/null || true

        echo "Ensuring Steam dependencies are protected..."
        # This command re-installs/verifies Steam's core 32-bit libraries
        # to make sure nothing essential was accidentally swept up.
        sudo apt-get install steam-libs-i386:i386 -y

        echo "Cleaning up residual unused packages..."
        sudo apt-get autoremove -y

        echo "Cleanup complete. Your system architecture remains i386-enabled for games."


        echo "Marking all installed packages as 'Manual' to prevent accidental removal..."
        sudo apt-mark manual $(apt-mark showauto) > /dev/null 2>&1
        echo "System is now locked. No packages will be autoremoved."
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        ;;

    zypper)
        ;;

    yum)
        ;;

    emerge)
        ;;

    eopkg)
        ;;

    apk)
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu|zorin|regataos)
        echo "UBUNTU_CODENAME: $UBUNTU_CODENAME"

        # i386 arch still required for Steam and 32-bit game libraries,
        # but we block Wine's i386 packages via apt preferences below.
        sudo dpkg --add-architecture i386

        # WoW64 (Wine 9+) runs 32-bit Windows apps via a PE-layer translation,
        # so no libwine:i386 or wine32 Linux packages are needed on the host.
        # Pin them to priority -1 (never install) to prevent apt pulling them
        # in as dependencies of wine-desktop-files or anything else.
        sudo tee /etc/apt/preferences.d/no-wine-i386 > /dev/null <<'EOF'
Package: wine32 wine32:i386 libwine:i386 wine-stable:i386 wine-devel:i386 wine-staging:i386 winehq-stable:i386
Pin: release *
Pin-Priority: -1
EOF
        echo "i386 Wine packages pinned to never-install."

        sudo mkdir -pm755 /etc/apt/keyrings

        # Always use WineHQ stable across all Ubuntu/Mint codenames.
        # Install wine-stable AND wine-stable-amd64 explicitly:
        #   wine-stable-amd64 : the actual WineHQ 64-bit binary in /opt/wine-stable/bin/
        #   wine-stable        : installs the /usr/bin/wine wrapper pointing at WineHQ.
        #                        Without this, /usr/bin/wine stays as Ubuntu's wine9.
        #                        On noble, WineHQ's wine-stable no longer hard-deps
        #                        wine-stable-i386:i386 (Ubuntu 24.04 dropped 32-bit wine),
        #                        so this is safe without pulling i386.
        # Do NOT install winehq-stable meta-package: it still chains to wine-stable-i386:i386
        # on older codenames via the winehq-stable → wine-stable → wine-stable-i386:i386 path.
        echo "Adding WineHQ stable repo for codename: $UBUNTU_CODENAME..."
        sudo wget -q -O /etc/apt/keyrings/winehq-archive.key https://dl.winehq.org/wine-builds/winehq.key
        sudo wget -qNP /etc/apt/sources.list.d/ https://dl.winehq.org/wine-builds/ubuntu/dists/$UBUNTU_CODENAME/winehq-$UBUNTU_CODENAME.sources
        sudo apt -qq update -y

        # Purge Ubuntu's wine packages before installing WineHQ's.
        # wine-binfmt (installed in PM section) depends on Ubuntu's 'wine', which
        # gets pulled back in after the earlier purge and then conflicts with
        # WineHQ's wine-stable at install time — causing apt to silently skip it.
        echo "Removing Ubuntu wine packages to unblock WineHQ install..."
        # BUG FIX: Added libwine:i386 and fonts-wine explicitly — apt glob "libwine*" does NOT
        # match arch-qualified names like libwine:i386, so it survived every previous purge.
        sudo apt-get purge -y wine wine64 "libwine*" libwine:i386 fonts-wine 2>/dev/null || true
        sudo apt-get autoremove -y 2>/dev/null || true

        # libtiff5 was renamed libtiff6 in Ubuntu 24.04 (noble) - detect which is available.
        LIBTIFF=$(apt-cache show libtiff6 &>/dev/null && echo libtiff6 || echo libtiff5)
        echo "Installing TIFF support: $LIBTIFF"
        # BUG FIX: Added wine-desktop-files — the PM-section purge "wine*" was removing it.
        # Removed --no-install-recommends — it silently drops deps needed for the /usr/bin/wine wrapper.
        sudo apt install --yes wine-stable wine-stable-amd64 wine-desktop-files "$LIBTIFF"
        if [ $? -ne 0 ]; then
            echo "ERROR: WineHQ install failed. Run: sudo apt install wine-stable wine-stable-amd64"
        fi

        # BUG FIX: Always force /usr/bin/ → WineHQ. The old [ ! -x ] guard skipped
        # this when Ubuntu wine9 already owned /usr/bin/wine, leaving wine --version
        # reporting 9.0 despite WineHQ being correctly installed.
        if [ -f /opt/wine-stable/bin/wine ]; then
            echo "Pointing /usr/bin/ at WineHQ wine-stable..."
            for _bin in wine wine64 wineboot winecfg wineserver; do
                [ -f "/opt/wine-stable/bin/$_bin" ] && sudo ln -sfn "/opt/wine-stable/bin/$_bin" "/usr/bin/$_bin"
            done
            echo "Done: $(wine --version 2>/dev/null || echo wine not callable yet)"
        else
            echo "ERROR: /opt/wine-stable/bin/wine not found — WineHQ install may have failed."
        fi

        # Register Windows PE executable format with binfmt_misc.
        # BUG FIX: Guard with -x — update-binfmts fails silently if /usr/bin/wine is missing.
        echo "Registering PE executables with binfmt_misc..."
        if [ -x /usr/bin/wine ]; then
            sudo update-binfmts --install wine /usr/bin/wine \
                --magic 'MZ' --offset 0 2>/dev/null || true
            sudo update-binfmts --enable wine 2>/dev/null || true
        else
            echo "Warning: /usr/bin/wine not found — binfmt_misc skipped."
        fi

        # MIME type + double-click handler for .bat and .cmd files.
        # .exe and .msi are already handled by the wine-desktop-files package.
        sudo tee /usr/share/mime/packages/wine-batch.xml > /dev/null <<'MIMEEOF'
<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="application/x-bat">
    <comment>Windows Batch File</comment>
    <glob pattern="*.bat"/>
    <glob pattern="*.cmd"/>
    <glob pattern="*.BAT"/>
    <glob pattern="*.CMD"/>
  </mime-type>
</mime-info>
MIMEEOF
        sudo update-mime-database /usr/share/mime

        sudo tee /usr/share/applications/wine-batch.desktop > /dev/null <<'DESKEOF'
[Desktop Entry]
Type=Application
Name=Wine Windows Batch Runner
Exec=/usr/bin/wine cmd /c %f
Icon=wine
MimeType=application/x-bat;
NoDisplay=true
Categories=Utility;
DESKEOF
        sudo update-desktop-database /usr/share/applications
        echo "Windows file associations configured (.exe .msi .bat .cmd)."
        ;;

    debian)
        # BUG FIX: This case body was orphaned — the debian) pattern label was accidentally
        # deleted during a refactor, leaving bare executable code between the linuxmint ;;
        # and the pop) label, causing a bash syntax error on every run.
        # BUG FIX: Was using fragile 'dpkg --status tzdata|grep Provides|cut -f2 -d-'
        # to detect codename. /etc/os-release (already sourced) provides VERSION_CODENAME
        # directly and reliably (e.g. 'bookworm', 'trixie').
        # BUG FIX: Pop!_OS is Ubuntu-based and moved to its own case below.
        CODENAME="$VERSION_CODENAME"
        echo "CODENAME: $CODENAME"
        sudo dpkg --add-architecture i386 && sudo apt update
        sudo mkdir -pm755 /etc/apt/keyrings
        sudo wget -q -O /etc/apt/keyrings/winehq-archive.key https://dl.winehq.org/wine-builds/winehq.key
        sudo wget -qNP /etc/apt/sources.list.d/ https://dl.winehq.org/wine-builds/debian/dists/$CODENAME/winehq-$CODENAME.sources
        sudo apt -y install --install-recommends winehq-stable
        ;;

    pop)
        # BUG FIX: Pop!_OS is Ubuntu-based (not Debian). It was grouped with Debian
        # and used the wrong WineHQ URL + wrong codename variable.
        # Pop!_OS provides UBUNTU_CODENAME in /etc/os-release (e.g. 'jammy', 'noble').
        echo "UBUNTU_CODENAME: $UBUNTU_CODENAME"
        sudo dpkg --add-architecture i386
        sudo mkdir -pm755 /etc/apt/keyrings

        # Same WoW64 approach as Ubuntu/Mint above — always WineHQ stable.
        sudo tee /etc/apt/preferences.d/no-wine-i386 > /dev/null <<'EOF'
Package: wine32 wine32:i386 libwine:i386 wine-stable:i386 wine-devel:i386 wine-staging:i386 winehq-stable:i386
Pin: release *
Pin-Priority: -1
EOF

        echo "Adding WineHQ stable repo for codename: $UBUNTU_CODENAME..."
        sudo wget -q -O /etc/apt/keyrings/winehq-archive.key https://dl.winehq.org/wine-builds/winehq.key
        sudo wget -qNP /etc/apt/sources.list.d/ https://dl.winehq.org/wine-builds/ubuntu/dists/$UBUNTU_CODENAME/winehq-$UBUNTU_CODENAME.sources
        sudo apt -qq update -y

        echo "Removing Ubuntu wine packages to unblock WineHQ install..."
        sudo apt-get purge -y wine wine64 "libwine*" libwine:i386 fonts-wine 2>/dev/null || true
        sudo apt-get autoremove -y 2>/dev/null || true

        # Same as Ubuntu/Mint: wine-stable provides /usr/bin/wine wrapper (WineHQ),
        # wine-stable-amd64 provides the actual binary. No i386 on noble.
        LIBTIFF=$(apt-cache show libtiff6 &>/dev/null && echo libtiff6 || echo libtiff5)
        echo "Installing TIFF support: $LIBTIFF"
        sudo apt install --yes wine-stable wine-stable-amd64 wine-desktop-files "$LIBTIFF"
        if [ $? -ne 0 ]; then
            echo "ERROR: WineHQ install failed. Run: sudo apt install wine-stable wine-stable-amd64"
        fi

        # BUG FIX: Always force /usr/bin/ → WineHQ. The old [ ! -x ] guard skipped
        # this when Ubuntu wine9 already owned /usr/bin/wine, leaving wine --version
        # reporting 9.0 despite WineHQ being correctly installed.
        if [ -f /opt/wine-stable/bin/wine ]; then
            echo "Pointing /usr/bin/ at WineHQ wine-stable..."
            for _bin in wine wine64 wineboot winecfg wineserver; do
                [ -f "/opt/wine-stable/bin/$_bin" ] && sudo ln -sfn "/opt/wine-stable/bin/$_bin" "/usr/bin/$_bin"
            done
            echo "Done: $(wine --version 2>/dev/null || echo wine not callable yet)"
        else
            echo "ERROR: /opt/wine-stable/bin/wine not found — WineHQ install may have failed."
        fi

        echo "Registering PE executables with binfmt_misc..."
        if [ -x /usr/bin/wine ]; then
            sudo update-binfmts --install wine /usr/bin/wine \
                --magic 'MZ' --offset 0 2>/dev/null || true
            sudo update-binfmts --enable wine 2>/dev/null || true
        else
            echo "Warning: /usr/bin/wine not found — binfmt_misc skipped."
        fi

        sudo tee /usr/share/mime/packages/wine-batch.xml > /dev/null <<'MIMEEOF'
<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="application/x-bat">
    <comment>Windows Batch File</comment>
    <glob pattern="*.bat"/>
    <glob pattern="*.cmd"/>
    <glob pattern="*.BAT"/>
    <glob pattern="*.CMD"/>
  </mime-type>
</mime-info>
MIMEEOF
        sudo update-mime-database /usr/share/mime

        sudo tee /usr/share/applications/wine-batch.desktop > /dev/null <<'DESKEOF'
[Desktop Entry]
Type=Application
Name=Wine Windows Batch Runner
Exec=/usr/bin/wine cmd /c %f
Icon=wine
MimeType=application/x-bat;
NoDisplay=true
Categories=Utility;
DESKEOF
        sudo update-desktop-database /usr/share/applications
        echo "Windows file associations configured (.exe .msi .bat .cmd)."
        ;;

    fedora|nobara)
        CODENAME=$VERSION_ID
        echo "Version ID: $CODENAME"
        sudo dnf config-manager addrepo --from-repofile=https://dl.winehq.org/wine-builds/fedora/$CODENAME/winehq.repo
        inst winehq-stable
        ;;

    opensuse-tumbleweed)
        zypper --non-interactive --quiet addrepo -C https://download.opensuse.org/repositories/Emulators:Wine/openSUSE_Tumbleweed/Emulators:Wine.repo
        zypper --non-interactive refresh
        inst wine
#        inst wine-32bit
        ;;

    almalinux)
        # BUG FIX: $VERSION_ID on AlmaLinux is '9.3' (includes minor version).
        # WineHQ RHEL repo URLs use the major version only (e.g. 'rhel/9/').
        # ${VERSION_ID%%.*} strips everything from the first dot onward.
        MAJOR_VER="${VERSION_ID%%.*}"
        echo "Version: $VERSION_ID -> Major: $MAJOR_VER"
        sudo dnf config-manager addrepo --from-repofile=https://dl.winehq.org/wine-builds/rhel/$MAJOR_VER/winehq.repo
        inst winehq-stable
        ;;

    arch|endeavouros)
        # Wine on Arch includes WoW64 (32-bit support built-in since Wine 8)
        inst wine
        ;;

    argent|biglinux|cachyos|garuda)
        # Arch-based distros – WoW64 built-in, no separate wine32 package needed
        inst wine
        ;;

    solus)
        inst wine
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # BUG FIX: This block was empty — wine was never installed on immutable OS!
        # winehq-stable cannot be configured via rpm-ostree with a custom repo.
        # Fall back to the stock 'wine' package available in the default overlay.
        # rpm-ostree layers it; a reboot is required before it becomes active
        # (LLScript.sh's wineboot autostart handles post-reboot initialisation).
        echo "Immutable OS: installing stock wine via rpm-ostree (winehq-stable not available via rpm-ostree)..."
        inst wine
        ;;

    *)
        #Just try anyway, worst case is it works!
        inst wine
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------
# winetricks and protontricks are not available via rpm-ostree on immutable OS
if ! [ "$IMMUTABLE_OS" = "true" ]; then
    inst winetricks
    inst protontricks
fi

# BUG FIX: winetricks depends on `wine`, which apt resolves to Ubuntu's wine9 package
# (not WineHQ wine-stable), reinstalling it and overwriting the /usr/bin/wine symlinks
# we set in OS Specific Tasks. Re-purge Ubuntu wine and re-force WineHQ symlinks here,
# AFTER winetricks/protontricks, so WineHQ always wins.
if [ "$PM" = "apt" ] && [ -f /opt/wine-stable/bin/wine ]; then
    echo "Re-purging Ubuntu wine (winetricks dependency pull-back)..."
    sudo apt-get purge -y wine wine64 libwine libwine:amd64 2>/dev/null || true
    echo "Re-pointing /usr/bin/ at WineHQ wine-stable..."
    for _bin in wine wine64 wineboot winecfg wineserver; do
        [ -f "/opt/wine-stable/bin/$_bin" ] && sudo ln -sfn "/opt/wine-stable/bin/$_bin" "/usr/bin/$_bin"
    done
    echo "Wine version confirmed: $(wine --version 2>/dev/null)"
fi

# Extract overlay - behaviour differs between normal and immutable OS:
#   Normal OS : /usr/share is writable, extract everything to /
#   Immutable  : /usr/share is read-only; extract only opt/LastOS (writable),
#                skip usr/ entirely, and save Overlay.tar + Scripts-Wine to
#                $HOME/.lltemp2/ so the deferred wineboot autostart can use
#                them after reboot (reboot wipes /tmp, .lltemp2 survives).
if [ "$IMMUTABLE_OS" = "true" ]; then
    echo "Immutable OS: extracting opt/LastOS only (skipping /usr/share - read-only)..."
    sudo tar -xvf Overlay.tar -C / --no-same-owner \
        --exclude='usr' --exclude='./usr' \
        --exclude='etc/xdg' --exclude='./etc/xdg' \
        2>/dev/null || true

    # Stage Overlay.tar and Scripts-Wine into $HOME/.lltemp2/ so they survive reboot.
    # /tmp is cleared on reboot; .lltemp2 in the user home persists until cleaned up.
    LLTEMP="$HOME/.lltemp2"
    mkdir -p "$LLTEMP"
    chmod 777 "$LLTEMP"
    echo "Staging Overlay.tar to $LLTEMP for post-reboot icon/desktop install..."
    cp Overlay.tar "$LLTEMP/Overlay.tar"
    echo "Staging Scripts-Wine for post-reboot wineboot..."
    mkdir -p "$LLTEMP/Scripts-Wine"
    chmod 777 "$LLTEMP/Scripts-Wine"
    # BUG FIX: path was '/opt/LastOS/Scripts-Wine' (leading slash) which never
    # matched archive members stored as 'opt/LastOS/Scripts-Wine' (no slash).
    # Silently failed due to 2>/dev/null, leaving Scripts-Wine empty after reboot.
    tar -xf Overlay.tar -C "$LLTEMP" opt/LastOS/Scripts-Wine --strip-components=2 --no-same-owner 2>/dev/null || true
else
    echo "Extracting overlay to /..."
    sudo tar -xvf Overlay.tar -C / --no-same-owner
fi

exit 0