#!/bin/bash

sudo mkdir -p /LastOS/Tools/Sanitize
sudo cp -R ./Sanitize /LastOS/Tools/
sudo chmod -R 777 /LastOS/Tools/Sanitize

sudo mkdir -p /root/.local/share/nemo/actions/action_scripts
sudo mkdir -p /root/.local/share/nemo/scripts/LastOS

sudo cp ./sanitize.sh /root/.local/share/nemo/actions/action_scripts/
sudo chmod 775 /root/.local/share/nemo/actions/action_scripts/sanitize.sh

sudo cp ./lastos-sanitize.nemo_action /root/.local/share/nemo/actions/
sudo chmod 775 /root/.local/share/nemo/actions/lastos-sanitize.nemo_action

sudo cp "./Sanitize (Clean)" /root/.local/share/nemo/scripts/LastOS/
sudo chmod 775 "/root/.local/share/nemo/scripts/LastOS/Sanitize (Clean)"

sudo cp "./Sanitize (Clean)" /root/.config/caja/scripts/LastOS/
sudo chmod 775 "/root/.config/caja/scripts/LastOS/Sanitize (Clean)"

sudo cp "./Sanitize (Clean)" /root/.local/share/nautilus/scripts/LastOS/
sudo chmod 775 "/root/.local/share/nautilus/scripts/LastOS/Sanitize (Clean)"

#KDE
sudo cp "./Sanitize.desktop" /usr/share/kio/servicemenus/
sudo chmod 775 "/usr/share/kio/servicemenus/Sanitize.desktop"

sudo cp ./sanitize.sh /LastOS/Tools/Sanitize/
sudo chmod 775 /LastOS/Tools/Sanitize/sanitize.sh