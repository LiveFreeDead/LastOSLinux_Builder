#!/bin/bash

#    echo "$@" > $HOME/Desktop/Test.txt

for f in "$@"
do

    #p=$@
    p=$f
    path=${p%/*}
    file=${p##*/}

    #echo "Path: $path  File: $file" > $HOME/Desktop/Path.txt
    
    cd "$path" && wine "z:/LastOS/Tools/Sanitize/Sanitize.exe" $file&

done
