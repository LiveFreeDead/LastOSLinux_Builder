#!/bin/bash

mkdir -p $HOME/.local/share/nemo/actions/action_scripts
mkdir -p $HOME/.local/share/nemo/scripts/LastOS

cp ./sanitize.sh $HOME/.local/share/nemo/actions/action_scripts/
chmod 775 $HOME/.local/share/nemo/actions/action_scripts/sanitize.sh

cp ./lastos-sanitize.nemo_action $HOME/.local/share/nemo/actions/
chmod 775 $HOME/.local/share/nemo/actions/lastos-sanitize.nemo_action

cp "./Sanitize (Clean)" $HOME/.local/share/nemo/scripts/LastOS/
chmod 775 "$HOME/.local/share/nemo/scripts/LastOS/Sanitize (Clean)"

cp "./Sanitize (Clean)" $HOME/.config/caja/scripts/LastOS/
chmod 775 "$HOME/.config/caja/scripts/LastOS/Sanitize (Clean)"

cp "./Sanitize (Clean)" $HOME/.local/share/nautilus/scripts/LastOS/
chmod 775 "$HOME/.local/share/nautilus/scripts/LastOS/Sanitize (Clean)"

mkdir -p $HOME/.local/share/icons
cp -rf ./icons $HOME/.local/share/