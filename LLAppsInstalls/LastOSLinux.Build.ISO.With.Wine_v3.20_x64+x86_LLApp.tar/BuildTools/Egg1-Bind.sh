cd /home/eggs/bin
sudo ./bind


