#!/bin/bash
#set -e # stop on error

eval ICONTHEME=$(gsettings get org.gnome.desktop.interface icon-theme)
APP=llfile
COMMENT="Install LLFiles"
EXEC=llapp
LOGO=/opt/LastOS/LLStore/Themes/LLStore.png

xdg-icon-resource install --context mimetypes --size 256 $LOGO application-x-$APP

xdg-icon-resource install --context mimetypes --size 256 --theme $ICONTHEME $LOGO application-x-$APP

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<mime-info xmlns=\"http://www.freedesktop.org/standards/shared-mime-info\">
    <mime-type type=\"application/x-$APP\">
        <comment>$COMMENT</comment>
        <icon name=\"application-x-$APP\"/>
        <glob pattern=\"*.lla\"/>
        <glob pattern=\"*.llg\"/>
        <glob pattern=\"*.LLApp.tar\"/>
        <glob pattern=\"*.LLGame.tar\"/>
        <glob pattern=\"*.app\"/>
        <glob pattern=\"*.apz\"/>
        <glob pattern=\"*.pgz\"/>
        <glob pattern=\"*.ppg\"/>
    </mime-type>
</mime-info>" > /tmp/$APP-mime.xml

xdg-mime install /tmp/$APP-mime.xml
rm /tmp/$APP-mime.xml
update-mime-database $HOME/.local/share/mime

echo "[Desktop Entry]
Name=LLFile
Exec=$EXEC -i %U
MimeType=application/x-$APP
Icon=application-x-$APP
Terminal=false
NoDisplay=true
Type=Application
Categories=
Comment=$COMMENT
"> /tmp/llfile_filetype.desktop
desktop-file-install --dir=$HOME/.local/share/applications /tmp/llfile_filetype.desktop
rm /tmp/llfile_filetype.desktop
update-desktop-database $HOME/.local/share/applications

xdg-mime default llfile_filetype.desktop application/x-$APP

chmod +x $HOME/.local/share/applications/llfile_filetype.desktop

update-mime-database $HOME/.local/share/mime

update-icon-caches $HOME/.local/share/icons/*

xdg-mime default wine.desktop application/x-ms-dos-executable
xdg-mime default wine.desktop application/x-msi
xdg-mime default wine.desktop application/x-ms-shortcut
xdg-mime default wine.desktop application/x-bat
xdg-mime default wine.desktop application/x-mswinurl

xdg-mime default xed.desktop text/plain

#xdg-mime default wine-extension-apz.desktop application/x-wine-extension-apz

#xdg-mime default llapp.desktop application/x-xz-compressed-tar



