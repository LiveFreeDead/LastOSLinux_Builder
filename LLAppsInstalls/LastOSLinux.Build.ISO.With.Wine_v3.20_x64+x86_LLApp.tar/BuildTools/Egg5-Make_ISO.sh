cd /home/eggs/bin
sudo ./mkisofs

