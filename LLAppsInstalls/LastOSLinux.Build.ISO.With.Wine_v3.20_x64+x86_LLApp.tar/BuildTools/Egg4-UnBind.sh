cd /home/eggs/bin
sudo ./ubind

