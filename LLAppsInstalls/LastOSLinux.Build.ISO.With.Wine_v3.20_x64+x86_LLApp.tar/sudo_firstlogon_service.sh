#!/usr/bin/env /bin/bash

#echo "Service Ran" > /LastOS/LastOSServiceRan.txt

######################## FIRST LOGON SUDO #############################
udevadm trigger
mkdir -p /media/LastOSLinuxUSBBoot
chown live:live /media/LastOSLinuxUSBBoot

#echo "apt update here" >> /LastOS/LastOSServiceRan.txt
killall mintUpdate
apt update
#mintupdate-launcher &

#Fix /lib /etc permissions so the Firewall works
chmod 755 /lib
chmod 755 /etc

#copy skel to root so it has the settings we want in the LiveOS and the installed one
cp -rf /etc/skel/. /root/

#Make cinnamon show all files as root
gsettings set org.nemo.preferences show-hidden-files true

#Change View Mode
gsettings set org.nemo.preferences default-folder-viewer 'compact-view'

#Configure Xed to be better
gsettings set org.x.editor.preferences.editor display-line-numbers true
gsettings set org.x.editor.preferences.editor bracket-matching false

#Show Full path in Titles
gsettings set org.nemo.preferences show-full-path-titles true

#Get thumbnails for images up to 4gb, should cover most movies etc too.
gsettings set org.nemo.preferences thumbnail-limit 4294967295

#Rename with pause
gsettings set org.nemo.preferences quick-renames-with-pause-in-between true


#Skipped check to make sure the routine even works
#echo "Disable Service" >> /LastOS/LastOSServiceRan.txt

#Disable Re-Running
mv /etc/sudo_firstlogon_service.sh /etc/sudo_firstlogon_service.sh.disabled

#Try to mount very last to give it all enough time to populate the mapper folder, maybe
mount /dev/mapper/s* /media/LastOSLinuxUSBBoot

sleep 5

#Try again after 5 seconds to give it the best chance, don't worry the script isn't visible
mount /dev/mapper/s* /media/LastOSLinuxUSBBoot

sleep 5

#Try again after 5 seconds to give it the best chance, don't worry the script isn't visible
mount /dev/mapper/s* /media/LastOSLinuxUSBBoot

killall mintUpdate
apt update
mintupdate-launcher &

exit 0
