#!/bin/bash

sudo udevadm trigger
sudo mkdir -p /media/LastOSLinuxUSBBoot
sudo chown live:live /media/LastOSLinuxUSBBoot
sudo mount /dev/mapper/s* /media/LastOSLinuxUSBBoot

sleep 5
#Try after a delay to give it the best chance
sudo mount /dev/mapper/s* /media/LastOSLinuxUSBBoot
