#!/bin/bash

#copy to
#/etc/penguins-eggs.d/custom/99-add-lastos-group.sh


# This runs inside the live-system chroot
groupadd -f lastos-users
