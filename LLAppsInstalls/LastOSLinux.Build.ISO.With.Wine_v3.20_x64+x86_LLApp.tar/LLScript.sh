#!/bin/bash

nemo $HOME &