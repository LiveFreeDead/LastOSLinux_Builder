#!/bin/bash

# Ensure running as root
if [[ $EUID -ne 0 ]]; then
    echo "This script must be run as root (or with sudo)"
    exit 1
fi

# Replace 'live' with your actual live session username if different
LIVEUSER="live"

# Allow Calamares to run without password
echo "$LIVEUSER ALL=(ALL) NOPASSWD: /usr/bin/calamares" > /etc/sudoers.d/calamares
echo "$LIVEUSER ALL=(ALL) NOPASSWD: /usr/bin/env" > /etc/sudoers.d/env

# Make sure permissions are correct
chmod 440 /etc/sudoers.d/calamares
chmod 440 /etc/sudoers.d/env

echo "Configured Calamares to not require sudo password for user $LIVEUSER"
