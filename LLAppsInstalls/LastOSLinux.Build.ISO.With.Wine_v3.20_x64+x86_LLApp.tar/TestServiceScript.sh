#!/bin/bash

mkdir -m a=rwx /Overlay

# 777 Everyone full access, 775 gives everyone read access only, root and owner get RWX
cp -rf Overlays/* /Overlay
chmod -R 775 /Overlay

#Copy the repaird Overlay to the root of the filesystem: the -a should be recursive and keep permissions etc
cp -a /Overlay/* /

#Delete the Overlay folder now as we don't need it and I don't need to change the ownership of it below
rm -r /Overlay

#Copy LastOS Service
#Make the sudo service executable and not editable by users
cp -f sudo_firstlogon_service.sh /etc/
chmod 755 "/etc/sudo_firstlogon_service.sh"
chmod +x "/etc/sudo_firstlogon_service.sh"

tar xf ./Service-SymLinks.tar -C /
