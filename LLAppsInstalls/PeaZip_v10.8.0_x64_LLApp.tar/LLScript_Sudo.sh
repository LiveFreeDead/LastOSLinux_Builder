#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

# Set to true to reinstall packages even if already installed (useful for fixing broken installs)
FORCE_REINSTALL=false

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
        ;;

    dnf)
        ;;

    apt)
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        ;;

    zypper)
        ;;

    yum)
        ;;

    emerge)
        ;;

    eopkg)
        ;;

    apk)
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use rpm-ostree via inst() for packages; they require a reboot to activate.
        # Avoid writing to /usr/share/ — use $HOME/.local/share/ instead.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

#https://github.com/peazip/PeaZip/releases/download/10.8.0/peazip_portable-10.8.0.LINUX.GTK2.x86_64.tar.gz

#inst build-essential
#inst gtk2.0
#inst libgtk2.0-dev

if $IMMUTABLE_OS; then
    # Immutable OS — /usr is read-only, install into user-local paths instead
    echo "Immutable OS detected — installing PeaZip to user-local paths."
    mkdir -p "$HOME/.local/bin"
    ln -s -f /opt/PeaZip/peazip "$HOME/.local/bin/peazip"

    mkdir -p "$HOME/.local/share/icons"
    cp -f ./res/share/icons/*.png "$HOME/.local/share/icons/"

    mkdir -p "$HOME/.local/share/applications"
    for f in ./res/share/batch/freedesktop_integration/additional-desktop-files/*.desktop; do
        # Rewrite Exec paths in desktop files to point to the local bin symlink
        sed "s|Exec=peazip|Exec=$HOME/.local/bin/peazip|g" "$f" | sudo tee "$HOME/.local/share/applications/$(basename "$f")" > /dev/null
    done
else
    # Standard install — write to system paths
    sudo ln -s -f /opt/PeaZip/peazip /usr/bin/peazip

    sudo cp -f ./res/share/icons/*.png /usr/share/icons/

    sudo cp -f ./res/share/batch/freedesktop_integration/additional-desktop-files/peazip-add-to-7z.desktop /usr/share/applications/
    sudo chmod +x /usr/share/applications/peazip-add-to-7z.desktop

    sudo cp -f ./res/share/batch/freedesktop_integration/additional-desktop-files/peazip-add-to-archive.desktop /usr/share/applications/
    sudo chmod +x /usr/share/applications/peazip-add-to-archive.desktop

    sudo cp -f ./res/share/batch/freedesktop_integration/additional-desktop-files/peazip-add-to-tar.desktop /usr/share/applications/
    sudo chmod +x /usr/share/applications/peazip-add-to-tar.desktop

    sudo cp -f ./res/share/batch/freedesktop_integration/additional-desktop-files/peazip-add-to-zip.desktop /usr/share/applications/
    sudo chmod +x /usr/share/applications/peazip-add-to-zip.desktop

    sudo cp -f ./res/share/batch/freedesktop_integration/additional-desktop-files/peazip-convert.desktop /usr/share/applications/
    sudo chmod +x /usr/share/applications/peazip-convert.desktop

    sudo cp -f ./res/share/batch/freedesktop_integration/additional-desktop-files/peazip-extract.desktop /usr/share/applications/
    sudo chmod +x /usr/share/applications/peazip-extract.desktop

    sudo cp -f ./res/share/batch/freedesktop_integration/additional-desktop-files/peazip-extract-here.desktop /usr/share/applications/
    sudo chmod +x /usr/share/applications/peazip-extract-here.desktop

    sudo cp -f ./res/share/batch/freedesktop_integration/additional-desktop-files/peazip-extract-smart.desktop /usr/share/applications/
    sudo chmod +x /usr/share/applications/peazip-extract-smart.desktop

    sudo cp -f ./res/share/batch/freedesktop_integration/additional-desktop-files/peazip-open.desktop /usr/share/applications/
    sudo chmod +x /usr/share/applications/peazip-open.desktop
fi

exit 0