#!/bin/bash

#LLStore Script v1.02

#---------- User Set Variables ----------

# (Add any variables your script needs here before the core loads)

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

# Source shared core: functions (flatinst), terminal/OS detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Core.sh" ]; then source "%ToolPath%/LLScript_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use $HOME/.local/share/ paths instead of /usr/share/, and note that
        # rpm-ostree installs require a reboot before packages are available.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$XDG_SESSION_DESKTOP" in
    *[Cc]innamon*)
        # Nemo context menu actions
        mkdir -p "$HOME/.local/share/nemo/actions"
        cp -f ./res/share/batch/freedesktop_integration/Nemo-actions/*.nemo_action "$HOME/.local/share/nemo/actions/"
        chmod +x "$HOME/.local/share/nemo/actions/"*

        # ~/.config/nemo/actions-tree.json — add PeaZip submenu if not present
        ACTIONS_TREE_FILE="$HOME/.config/nemo/actions-tree.json"
        PEAZIP_MENU_JSON='{
  "uuid": "PeaZip",
  "type": "submenu",
  "user-label": "PeaZip",
  "user-icon": "peazip",
  "children": [
    {
      "uuid": "PeaZip, add to archive.nemo_action",
      "type": "action",
      "user-label": null,
      "user-icon": null
    },
    {
      "uuid": "PeaZip, extract archive .nemo_action",
      "type": "action",
      "user-label": null,
      "user-icon": null
    },
    {
      "uuid": "PeaZip, extract here.nemo_action",
      "type": "action",
      "user-label": null,
      "user-icon": null
    },
    {
      "uuid": "PeaZip, open as archive.nemo_action",
      "type": "action",
      "user-label": null,
      "user-icon": null
    },
    {
      "uuid": "PeaZip, test.nemo_action",
      "type": "action",
      "user-label": null,
      "user-icon": null
    }
  ]
}'
        if [[ ! -f "$ACTIONS_TREE_FILE" ]]; then
            mkdir -p "$(dirname "$ACTIONS_TREE_FILE")"
            echo '{"toplevel": []}' | jq . > "$ACTIONS_TREE_FILE"
            echo "Created initial actions-tree.json."
        fi
        jq --argjson new_item "$PEAZIP_MENU_JSON" '
          .toplevel |= (
            if map(.uuid == "PeaZip") | any then .
            else . + [$new_item]
            end
          )
        ' "$ACTIONS_TREE_FILE" > "$ACTIONS_TREE_FILE.tmp" && mv "$ACTIONS_TREE_FILE.tmp" "$ACTIONS_TREE_FILE"
        echo "Updated Nemo actions-tree.json."
        ;;

    gnome|ubuntu|ubuntu-xorg)
        # Nautilus scripts submenu
        mkdir -p "$HOME/.local/share/nautilus/scripts/PeaZip"
        cp -rf ./res/share/batch/freedesktop_integration/Nautilus-scripts/PeaZip/. "$HOME/.local/share/nautilus/scripts/PeaZip/"
        chmod +x "$HOME/.local/share/nautilus/scripts/PeaZip/"*
        ;;

    kde|KDE|plasma)
        # Dolphin service menus
        mkdir -p "$HOME/.local/share/kio/servicemenus"
        cp -f ./res/share/batch/freedesktop_integration/KDE-servicemenus/KDE6-dolphin/peazip-kde6.desktop "$HOME/.local/share/kio/servicemenus/peazip-kde6.desktop"
        chmod +x "$HOME/.local/share/kio/servicemenus/peazip-kde6.desktop"
        ;;

    mate|lightdm-xsession)
        # Caja scripts submenu (same pattern as Nautilus)
        mkdir -p "$HOME/.local/share/caja/scripts/PeaZip"
        if [ -d "./res/share/batch/freedesktop_integration/Caja-scripts/PeaZip" ]; then
            cp -rf ./res/share/batch/freedesktop_integration/Caja-scripts/PeaZip/. "$HOME/.local/share/caja/scripts/PeaZip/"
        else
            # Fallback: Caja scripts are compatible with Nautilus scripts
            cp -rf ./res/share/batch/freedesktop_integration/Nautilus-scripts/PeaZip/. "$HOME/.local/share/caja/scripts/PeaZip/"
        fi
        chmod +x "$HOME/.local/share/caja/scripts/PeaZip/"*
        ;;

    xfce)
        # Thunar custom actions — merge into uca.xml
        mkdir -p "$HOME/.config/Thunar"
        if [ -f "./res/share/batch/freedesktop_integration/Thunar-actions/uca.xml" ]; then
            if [ ! -f "$HOME/.config/Thunar/uca.xml" ]; then
                cp -f ./res/share/batch/freedesktop_integration/Thunar-actions/uca.xml "$HOME/.config/Thunar/uca.xml"
                echo "Installed Thunar custom actions."
            else
                # Back up existing uca.xml and append PeaZip actions before closing </actions> tag
                cp -f "$HOME/.config/Thunar/uca.xml" "$HOME/.config/Thunar/uca.xml.bak"
                PEAZIP_ACTIONS=$(grep -oP '(?<=<action>).*(?=</action>)' ./res/share/batch/freedesktop_integration/Thunar-actions/uca.xml || true)
                if [ -n "$PEAZIP_ACTIONS" ] && ! grep -q "PeaZip" "$HOME/.config/Thunar/uca.xml"; then
                    # Extract just the <action>...</action> blocks and insert before </actions>
                    BLOCKS=$(grep -Pzo '(?s)<action>.*?</action>' ./res/share/batch/freedesktop_integration/Thunar-actions/uca.xml | tr -d '\0')
                    sed -i "s|</actions>|${BLOCKS}\n</actions>|" "$HOME/.config/Thunar/uca.xml"
                    echo "Merged PeaZip actions into existing Thunar uca.xml."
                else
                    echo "PeaZip actions already present in Thunar uca.xml, skipping."
                fi
            fi
        fi
        ;;

    budgie-desktop)
        # Budgie uses Nautilus
        mkdir -p "$HOME/.local/share/nautilus/scripts/PeaZip"
        cp -rf ./res/share/batch/freedesktop_integration/Nautilus-scripts/PeaZip/. "$HOME/.local/share/nautilus/scripts/PeaZip/"
        chmod +x "$HOME/.local/share/nautilus/scripts/PeaZip/"*
        ;;

    zorin)
        # Zorin Core/Pro uses Nautilus; Zorin Lite uses XFCE/Thunar
        # Check which file manager is present
        if command -v nautilus &>/dev/null; then
            mkdir -p "$HOME/.local/share/nautilus/scripts/PeaZip"
            cp -rf ./res/share/batch/freedesktop_integration/Nautilus-scripts/PeaZip/. "$HOME/.local/share/nautilus/scripts/PeaZip/"
            chmod +x "$HOME/.local/share/nautilus/scripts/PeaZip/"*
        fi
        if command -v thunar &>/dev/null && [ -f "./res/share/batch/freedesktop_integration/Thunar-actions/uca.xml" ]; then
            mkdir -p "$HOME/.config/Thunar"
            if [ ! -f "$HOME/.config/Thunar/uca.xml" ]; then
                cp -f ./res/share/batch/freedesktop_integration/Thunar-actions/uca.xml "$HOME/.config/Thunar/uca.xml"
            fi
        fi
        ;;

    lxde)
        ;;

    unity)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        # OpenSUSE defaults to KDE or GNOME — handle whichever file manager is present
        if command -v dolphin &>/dev/null; then
            mkdir -p "$HOME/.local/share/kio/servicemenus"
            cp -f ./res/share/batch/freedesktop_integration/KDE-servicemenus/KDE6-dolphin/peazip-kde6.desktop "$HOME/.local/share/kio/servicemenus/peazip-kde6.desktop"
            chmod +x "$HOME/.local/share/kio/servicemenus/peazip-kde6.desktop"
        elif command -v nautilus &>/dev/null; then
            mkdir -p "$HOME/.local/share/nautilus/scripts/PeaZip"
            cp -rf ./res/share/batch/freedesktop_integration/Nautilus-scripts/PeaZip/. "$HOME/.local/share/nautilus/scripts/PeaZip/"
            chmod +x "$HOME/.local/share/nautilus/scripts/PeaZip/"*
        fi
        ;;

    *)
        echo "Unknown Desktop Environment ($XDG_SESSION_DESKTOP). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# To install user Flatpaks (no sudo required):
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

mkdir -p "$HOME/.local/share/icons"
cp -f ./res/share/icons/peazip.png "$HOME/.local/share/icons/"

exit 0