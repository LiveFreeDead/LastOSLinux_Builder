#!/bin/bash

# --- 1. SETUP NAMED PIPE FOR YAD ---
PIPE=$(mktemp -u)
mkfifo "$PIPE"
exec 3<> "$PIPE"

update_progress() {
    echo "$1" >&3
    echo "# $2" >&3
}

# --- 2. INITIAL ENVIRONMENT SETUP ---

# Detect DE and session type for conditional logic below
IS_CINNAMON=false
IS_WAYLAND=false
CURRENT_DE="${XDG_CURRENT_DESKTOP,,}"
[[ "$CURRENT_DE" == *cinnamon* || "$DESKTOP_SESSION" == *cinnamon* ]] && IS_CINNAMON=true
[[ "${XDG_SESSION_TYPE,,}" == "wayland" ]] && IS_WAYLAND=true

command -v numlockx >/dev/null && numlockx on

# Nemo preferences — only on Cinnamon/Nemo installs
if $IS_CINNAMON && command -v nemo >/dev/null; then
    gsettings set org.nemo.preferences show-hidden-files false 2>/dev/null
fi

# Ctrl+Alt+Backspace to kill X — only meaningful on X11
if ! $IS_WAYLAND; then
    gsettings set org.gnome.libgnomekbd.keyboard options "['terminate\tterminate:ctrl_alt_bksp']" 2>/dev/null
fi

rm "$HOME/.config/autostart/First Logon.desktop" 2>/dev/null

mkdir -p "$HOME/.config/gtk-3.0"
echo -e "headerbar {\n   min-height: 22px;\n}" > "$HOME/.config/gtk-3.0/gtk.css"

# Cinnamon menu logo fix — Mint-specific schema/path
if $IS_CINNAMON; then
    MENU_PATH="$HOME/.config/cinnamon/spices/menu@cinnamon.org/"
    if [ -d "$MENU_PATH" ]; then
        (cd "$MENU_PATH" && grep -lZ '"value": "linuxmint-logo-ring-symbolic"' 0.json | xargs -0 sed -i 's|"value": "linuxmint-logo-ring-symbolic"|"value": "/usr/share/icons/Start Button.png"|g' 2>/dev/null)
    fi
fi

######################### SETUP LIVE USER ##############################
if [ "$(whoami)" == "live" ]; then
    if $IS_CINNAMON; then
        gsettings set org.cinnamon.desktop.background picture-uri 'file:///usr/share/backgrounds/lastos/LiveWallpaper.jpg' 2>/dev/null
        gsettings set org.nemo.preferences show-hidden-files true 2>/dev/null
    fi
    killall conky 2>/dev/null
    mv -f "$HOME/.config/conky/conky.conf" "$HOME/.config/conky/conky.conf.old" 2>/dev/null
    mv -f "$HOME/.config/conky/conky.conf.live" "$HOME/.config/conky/conky.conf" 2>/dev/null
    command -v conky >/dev/null && conky &
fi



# --- Setup YAD to show on the LiveOS now ---
YAD_PID=""
if command -v yad >/dev/null && ! $IS_WAYLAND; then
    read x y < <(xrandr --current | grep -oP '\d+x\d+' | head -n1 | tr x ' ')
    POSX2=$(($x/4))
    POSX=$(($POSX2-200))

    yad --progress \
        --image="dialog-information" \
        --image-on-top \
        --no-escape \
        --window-icon="dialog-information" \
        --no-buttons \
        --on-top \
        --geometry=340x100+$POSX+0 \
        --title "LastOSLinux Installing" \
        --text "Initializing system setup..." <&3 &
    YAD_PID=$!
fi

update_progress 5 "Preparing Installation..."

# --- 3. OVERLAY MIGRATION (RECURSIVE MV MERGE) ---
fast_move_merge() {
    local src="$1"
    local dst="$2"
    mkdir -p "$dst"
    shopt -s dotglob
    for item in "$src"/*; do
        [ -e "$item" ] || continue
        local name=$(basename "$item")
        if [ -d "$item" ] && [ -d "$dst/$name" ]; then
            fast_move_merge "$item" "$dst/$name"
        else
            mv -f "$item" "$dst/" 2>/dev/null
        fi
    done
    shopt -u dotglob
}

if [ -d "/opt/LastOS/skel" ]; then
    update_progress 10 "Merging system overlays..."
    fast_move_merge "/opt/LastOS/skel" "$HOME"
    rm -rf /opt/LastOS/skel/* 2>/dev/null
fi

# Fix shortcuts to point to the new user
find "$HOME/.local/share/applications" -type f -name "*.desktop" | while read -r file; do
    sed -i "s|/home/lastos/|$HOME/|g" "$file"
done

# --- 3a. WINE PREFIX USER RENAMING & FIXES ---
WINE_DIR="$HOME/.wine"
OLD_USER="lastos"
NEW_USER=$(whoami)

if [ -d "$WINE_DIR" ]; then
    update_progress 15 "Adapting Wine profile to $NEW_USER..."
    
    # 1. Rename the physical user folder inside Wine
    if [ -d "$WINE_DIR/drive_c/users/$OLD_USER" ]; then
        mv "$WINE_DIR/drive_c/users/$OLD_USER" "$WINE_DIR/drive_c/users/$NEW_USER" 2>/dev/null
    fi

    # 2. Update the Registry files (Search and Replace paths)
    if ls "$WINE_DIR"/*.reg >/dev/null 2>&1; then
        find "$WINE_DIR" -maxdepth 1 -name "*.reg" -exec sed -i "s/$OLD_USER/$NEW_USER/g" {} +
    fi

    # 3. FIX DOSDEVICES (Drive mapping)
    rm -f "$WINE_DIR/dosdevices/c:" "$WINE_DIR/dosdevices/z:" 2>/dev/null
    ln -s "../drive_c" "$WINE_DIR/dosdevices/c:"
    ln -s "/" "$WINE_DIR/dosdevices/z:"

    # 4. MANUAL SYMLINK RECONSTRUCTION (Standard Naming)
    W_USER_DIR="$WINE_DIR/drive_c/users/$NEW_USER"
    if [ -d "$W_USER_DIR" ]; then
        # Clean out both old styles to ensure a fresh link
        rm -rf "$W_USER_DIR/Desktop" "$W_USER_DIR/Documents" "$W_USER_DIR/Videos" "$W_USER_DIR/Music" "$W_USER_DIR/Pictures" "$W_USER_DIR/Downloads" 2>/dev/null
        rm -rf "$W_USER_DIR/My Documents" "$W_USER_DIR/My Videos" "$W_USER_DIR/My Music" "$W_USER_DIR/My Pictures" 2>/dev/null
        
        # Ensure target dirs exist in Linux Home
        mkdir -p "$HOME/Desktop" "$HOME/Documents" "$HOME/Videos" "$HOME/Music" "$HOME/Pictures" "$HOME/Downloads"
        
        # Create fresh symlinks using standard names
        ln -sf "$HOME/Desktop" "$W_USER_DIR/Desktop"
        ln -sf "$HOME/Documents" "$W_USER_DIR/Documents"
        ln -sf "$HOME/Videos" "$W_USER_DIR/Videos"
        ln -sf "$HOME/Music" "$W_USER_DIR/Music"
        ln -sf "$HOME/Pictures" "$W_USER_DIR/Pictures"
        ln -sf "$HOME/Downloads" "$W_USER_DIR/Downloads"
    fi

    # Initialize Wine for current environment
    update_progress 20 "Initializing Wine paths..."

#Make it being a WINE build known in firstlogon.sh - This will stop winecfg running in the LiveOS
    if [ "$(whoami)" == "live" ]; then
#Use the actual /etc/skel version because it will be available when this script runs
        if [ -f /etc/skel/.wineinstall ]; then
            wine wineboot --update --init
        fi
    else
#If not live OS, always do winecfg
            wine wineboot --update --init
    fi
fi

update_progress 25 "Setting up Desktop shortcuts..."
cp /opt/LastOS/LastOS-ReadMe.desktop "$HOME/Desktop/" 2>/dev/null
chmod +x "$HOME/Desktop/LastOS-ReadMe.desktop" 2>/dev/null
chmod +x "/opt/LastOS/*.desktop" 2>/dev/null

#By Default Flatpak shortcuts don't seem to show up in the LiveOS or the installed OS, this should fix that.
update_progress 25 "Setting up Flatpak Desktop shortcuts..."
for file in ~/.local/share/flatpak/exports/share/applications/*.desktop; do 
  ln -s "$file" ~/.local/share/applications/
done
for file in /var/lib/flatpak/exports/share/applications/*.desktop; do 
  ln -s "$file" ~/.local/share/applications/
done


######################### EXIT LIVE USER ##############################
if [ "$(whoami)" == "live" ]; then
    exec 3>&-
    [ -n "$YAD_PID" ] && kill "$YAD_PID" 2>/dev/null
    rm "$PIPE"
    exit
fi

######################### SETUP NEW USER ##############################

terms=(gnome-terminal konsole x-terminal-emulator xterm xfce4-terminal)
for t in ${terms[*]}; do
    if command -v "$t" >/dev/null; then OSTERM=$t; break; fi
done

# slick-greeter login background — only on Mint/Ubuntu with slick-greeter
if gsettings get x.dm.slick-greeter background >/dev/null 2>&1; then
    gsettings set x.dm.slick-greeter background '/usr/share/backgrounds/lastos/Login.jpg' 2>/dev/null
fi

update_progress 25 "Setting up Desktop shortcuts..."
cp /opt/LastOS/*.desktop "$HOME/Desktop/" 2>/dev/null
chmod +x "$HOME/Desktop/*.desktop" 2>/dev/null
chmod +x "/opt/LastOS/*.desktop" 2>/dev/null

update_progress 30 "Adding Flatpak Repositories..."
flatpak remote-add --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo
flatpak remote-add --user --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo

command -v mintupdate-launcher >/dev/null && { killall mintUpdate 2>/dev/null; mintupdate-launcher & }

update_progress 40 "Installing Mono and Gecko..."
if ls "$HOME/.cache/wine/"*.msi >/dev/null 2>&1; then
    for msi in "$HOME/.cache/wine/"*.msi; do
        wine msiexec /i "$msi" /quiet /qn 2>/dev/null
    done
fi

grep -qF '/.wine/drive_c' ~/.config/gtk-3.0/bookmarks || echo "file://$HOME/.wine/drive_c C:\\ (Wine)" >> ~/.config/gtk-3.0/bookmarks

update_progress 65 "Installing Linux Apps..."
for f in /opt/LastOS/LinuxApps/*; do [ -e "$f" ] && llapp -install "$f"; done

update_progress 75 "Installing Linux Games..."
for f in /opt/LastOS/LinuxGames/*; do [ -e "$f" ] && llapp -install "$f"; done

update_progress 85 "Installing Windows Games..."
for f in /opt/LastOS/WindowsGames/*; do [ -e "$f" ] && llapp -install "$f"; done

update_progress 90 "Applying Fonts and Registry Tweaks..."
[ -f "/opt/LastOS/Scripts-Wine/Fonts.exe" ] && wine "/opt/LastOS/Scripts-Wine/Fonts.exe"
[ -f "/opt/LastOS/Scripts-Wine/LastOS-Tweaks.reg" ] && wine regedit /s "/opt/LastOS/Scripts-Wine/LastOS-Tweaks.reg"

update_progress 95 "Finalizing Windows Apps..."
for f in /opt/LastOS/WindowsApps/*; do [ -e "$f" ] && llapp -install "$f"; done

[ -f "/opt/LastOS/Scripts/AddLastOSFileTypes.sh" ] && bash "/opt/LastOS/Scripts/AddLastOSFileTypes.sh"

update_progress 100 "Finishing up..."

# LastOS Settings ran here at the final stage
[ -f "/opt/LastOS/LastOSLinux_Settings/Settings" ] && /opt/LastOS/LastOSLinux_Settings/Settings &

command -v mintupdate-launcher >/dev/null && { killall mintUpdate 2>/dev/null; mintupdate-launcher & }
gio trash --empty

exec 3>&-
[ -n "$YAD_PID" ] && kill "$YAD_PID" 2>/dev/null
rm "$PIPE"

if command -v yad >/dev/null && ! $IS_WAYLAND; then
    yad --image="dialog-information" \
      --no-escape \
      --timeout-indicator=bottom \
      --window-icon=dialog-information \
      --no-buttons \
      --on-top \
      --geometry=340x100+$POSX+0 \
      --timeout=10 \
      --title "LastOSLinux Installed" \
      --text "\n Finished Installing LastOSLinux\n\n * You MUST reboot once to install flatpaks\n I recommend a system update before rebooting" &
fi
