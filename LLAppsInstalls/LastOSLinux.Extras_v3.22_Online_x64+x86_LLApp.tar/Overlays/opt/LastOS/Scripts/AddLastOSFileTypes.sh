#!/bin/bash

# --- Setup Variables ---
eval ICONTHEME=$(gsettings get org.gnome.desktop.interface icon-theme)
LOGO="/opt/LastOS/LLStore/Themes/LLStore.png"
MIME_DIR="$HOME/.local/share/mime"
APP_DIR="$HOME/.local/share/applications"
MIMEAPPS="$HOME/.config/mimeapps.list"

mkdir -p "$MIME_DIR" "$APP_DIR" "$HOME/.config"
touch "$MIMEAPPS"

# --- Helper Functions ---

# Set a mime default handler
set_default() {
    local desktop="$1"; shift
    for mime in "$@"; do
        xdg-mime default "$desktop" "$mime"
    done
}

# Add a secondary "Open With" association without changing the default
add_association() {
    local desktop="$1"; shift
    # Ensure [Added Associations] section exists
    grep -q '^\[Added Associations\]' "$MIMEAPPS" || echo -e "\n[Added Associations]" >> "$MIMEAPPS"
    for mime in "$@"; do
        if grep -q "^${mime}=" "$MIMEAPPS"; then
            # Append if not already listed
            grep -q "${desktop}" <<< "$(grep "^${mime}=" "$MIMEAPPS")" || \
                sed -i "s|^${mime}=.*|&${desktop};|" "$MIMEAPPS"
        else
            sed -i "/^\[Added Associations\]/a ${mime}=${desktop};" "$MIMEAPPS"
        fi
    done
}

# Install an icon for a mime type
install_icon() {
    local mime_name="$1"
    xdg-icon-resource install --context mimetypes --size 256 "$LOGO" "$mime_name"
    xdg-icon-resource install --context mimetypes --size 256 --theme "$ICONTHEME" "$LOGO" "$mime_name"
}

# --- 1. Icons ---
install_icon "application-x-llfile"

# --- 2. MIME Type Definitions ---
cat > /tmp/lastos-mime.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
    <mime-type type="application/x-llfile">
        <comment>LastOS App Installer</comment>
        <icon name="application-x-llfile"/>
        <glob pattern="*.lla"/>
        <glob pattern="*.llg"/>
        <glob pattern="*.app"/>
        <glob pattern="*.ppg"/>
        <glob pattern="*.LLApp.tar"/>
        <glob pattern="*.LLGame.tar"/>
    </mime-type>
    <mime-type type="application/x-llarchive">
        <comment>LastOS Compressed Archive</comment>
        <icon name="application-x-llfile"/>
        <glob pattern="*.apz"/>
        <glob pattern="*.pgz"/>
    </mime-type>
</mime-info>
EOF

xdg-mime install /tmp/lastos-mime.xml
update-mime-database "$MIME_DIR"

# --- 3. Desktop Entry ---
cat > "$APP_DIR/llfile_filetype.desktop" << 'EOF'
[Desktop Entry]
Name=LLFile Installer
Exec=/usr/bin/llapp -i %U
MimeType=application/x-llfile;application/x-llarchive;
Icon=application-x-llfile
Terminal=false
NoDisplay=true
Type=Application
Categories=System;
Comment=Install LLFiles
EOF

update-desktop-database "$APP_DIR"

# --- 4. Detect installed apps ---

# Detect archive manager (Linux Mint typically uses Engrampa)
ARCHIVER=$(
    for candidate in engrampa.desktop file-roller.desktop ark.desktop xarchiver.desktop; do
        [ -f "/usr/share/applications/$candidate" ] && echo "$candidate" && break
    done
)

# Detect text editor
EDITOR=$(gsettings get org.gnome.desktop.interface document-font-name 2>/dev/null)
EDITOR=$(
    for candidate in xed.desktop gedit.desktop mousepad.desktop kate.desktop; do
        [ -f "/usr/share/applications/$candidate" ] && echo "$candidate" && break
    done
)

# --- 5. Set Defaults ---
set_default "llfile_filetype.desktop" \
    "application/x-llfile" \
    "application/x-llarchive"

set_default "wine.desktop" \
    "application/x-ms-dos-executable" \
    "application/x-msi" \
    "application/x-ms-shortcut" \
    "application/x-bat" \
    "application/x-mswinurl"

[ -n "$EDITOR" ] && set_default "$EDITOR" "text/plain"

# --- 6. Secondary "Open With" Associations (non-default) ---

# Archive manager as an option for compressed ll archives
[ -n "$ARCHIVER" ] && add_association "$ARCHIVER" \
    "application/x-llarchive"

# Text editor as an option for ll installer files
[ -n "$EDITOR" ] && add_association "$EDITOR" \
    "application/x-llfile"

# --- 7. Final Cache Updates ---
update-mime-database "$MIME_DIR"
update-icon-caches "$HOME/.local/share/icons/"* 2>/dev/null

echo "File types configured successfully."
