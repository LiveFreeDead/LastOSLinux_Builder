#!/bin/bash

#Fix /opt/LastOS Ownership (775 might be enough, but I'll go 777 as I want all users to access this folder)
#Chown Sets it to User ID 1000 (All Users)
sudo chmod -R 777 "/opt/LastOS"
sudo chown -f -Rc $USER:$USER "/opt/LastOS"
sudo chown -f -R :users "/opt/LastOS"

#Make the sudo service executable and not editable by users
sudo chmod 755 "/opt/LastOS/Scripts/sudo_firstlogon_service.sh"
#sudo chmod 775 "/opt/LastOS/Scripts/sudo_firstlogon_service.sh"
#sudo chown root:root "/opt/LastOS/Scripts/sudo_firstlogon_service.sh"
sudo chmod +x "/opt/LastOS/Scripts/sudo_firstlogon_service.sh"

#Copy shortcuts to menu (Just in case)
sudo cp -a /opt/LastOS/*.desktop $HOME/.local/share/applications
sudo cp -a /opt/LastOS/Tools/*.desktop $HOME/.local/share/applications
