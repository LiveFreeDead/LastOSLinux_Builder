#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
        ;;

    dnf)
        ;;

    apt)
    inst synaptic
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        ;;

    zypper)
        ;;

    yum)
        ;;

    emerge)
        ;;

    eopkg)
        ;;

    apk)
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use rpm-ostree via inst() for packages; they require a reboot to activate.
        # Avoid writing to /usr/share/ — use $HOME/.local/share/ instead.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        rsync -a LinuxMint_Cinnamon/ "$OVERLAY_STAGING/"
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

# Resolve the real invoking user's home — avoids /root when run via sudo
REAL_USER="${SUDO_USER:-$USER}"
REAL_HOME=$(getent passwd "$REAL_USER" | cut -d: -f6)

# Define paths
OVERLAY_STAGING="$REAL_HOME/Overlay"
SKEL_TARGET="$OVERLAY_STAGING/etc/skel"

# 1. Create staging with correct permissions
mkdir -p "$OVERLAY_STAGING"

# 2. Sync local Overlays folder to Staging
# -a (archive: keeps symlinks, permissions, times)
rsync -a Overlays/ "$OVERLAY_STAGING/"

# 3. --- DYNAMIC SYNC: Grab latest Cinnamon/Nemo components ---
# This pulls the active, updated configs from the real user into the staging area
echo "Syncing latest Cinnamon/Nemo extensions and actions..."
mkdir -p "$SKEL_TARGET/.local/share"
mkdir -p "$SKEL_TARGET/.config/cinnamon"

# Sync Nemo Actions, Desklets, and Extensions from CURRENT USER to SKEL
for folder in "nemo/actions" "cinnamon/desklets" "cinnamon/extensions" "cinnamon/spices"; do
    if [ -d "$REAL_HOME/.local/share/$folder" ]; then
        mkdir -p "$SKEL_TARGET/.local/share/$folder"
        rsync -a --delete "$REAL_HOME/.local/share/$folder/" "$SKEL_TARGET/.local/share/$folder/"
    fi
done

# 4. Set Specific Executable Permissions
# .desktop autostart files need executable bit set for some display managers
# Deletion is controlled by directory ownership after skel copy, not file perms — 755 is correct
chmod 755 "$OVERLAY_STAGING/etc/skel/.config/autostart/First Logon.desktop"
chmod +x "$OVERLAY_STAGING/opt/LastOS/Scripts/"*.sh

# Set /opt/LastOS ownership and permissions (root-owned, lastos-users group, group-writable)
chown -R root:lastos-users "$OVERLAY_STAGING/opt/LastOS"
chmod -R 775 "$OVERLAY_STAGING/opt/LastOS"

# skel must stay world-writable — it's moved around by any user post-install and linked in LiveOS
chmod -R 777 "$OVERLAY_STAGING/etc/skel"

# 5. Apply to Root Filesystem
# Use rsync to merge staging into the real root
rsync -a "$OVERLAY_STAGING/" /

# 6. Sync Cache/Config to current user (Wine/Thumbnailer bits)
# Run as the real user so files are owned correctly — not as root
# -u (update) ensures we don't overwrite newer files with older ones
sudo -u "$REAL_USER" rsync -au "$SKEL_TARGET/.cache/" "$REAL_HOME/.cache/"
sudo -u "$REAL_USER" rsync -au "$SKEL_TARGET/.config/" "$REAL_HOME/.config/"
sudo -u "$REAL_USER" rsync -au "$SKEL_TARGET/.local/" "$REAL_HOME/.local/"

# 7. Cleanup — remove First Logon autostart from the installing user so it doesn't re-run
rm -f "$REAL_HOME/.config/autostart/First Logon.desktop"
rm -rf "$OVERLAY_STAGING"

echo "System and Skel updated successfully."

exit 0