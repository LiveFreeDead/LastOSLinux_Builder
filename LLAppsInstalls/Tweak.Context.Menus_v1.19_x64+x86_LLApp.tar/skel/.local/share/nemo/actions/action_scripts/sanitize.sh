#!/bin/bash
for f in "$@"
do
    /opt/Sanitize/sanitize "$f"
done
