#!/bin/bash
for f in "$@"
do
    sanitize "$f"
done
