#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

sudo -v
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac) ;; dnf) ;; apt) ;; pacman) ;; zypper) ;; yum) ;; emerge) ;; eopkg) ;; apk) ;; *) ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
case "$ID" in
    manjaro) ;; linuxmint|ubuntu) ;; debian|pop) ;; fedora|nobara) ;;
    opensuse-tumbleweed|opensuse-leap) ;; almalinux) ;; arch|endeavouros) ;;
    argent) ;; biglinux) ;; cachyos) ;; deepin) ;; garuda) ;; regataos) ;;
    solus) ;; zorin) ;; bazzite|silverblue|kinoite|sericea|aurora|bluefin) ;;
    *) echo "Unknown Distribution ($ID). Script section skipped" ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        sudo cp -rf ./nemo/. /etc/skel/.local/share/nemo/
        sudo cp -rf ./nemo/. /root/.local/share/nemo/
        sudo find /etc/skel/.local/share/nemo/actions/action_scripts -type f -exec chmod +x {} \; 2>/dev/null || true
        sudo find /root/.local/share/nemo/actions/action_scripts     -type f -exec chmod +x {} \; 2>/dev/null || true
        ;;
    gnome|ubuntu|ubuntu-xorg) ;; kde|KDE|plasma) ;; lxde) ;;
    mate|lightdm-xsession) ;; unity) ;; xfce) ;;
    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop) ;; budgie-desktop) ;; LXQt) ;;
    anduinos|anduinos-xorg) ;; deepin) ;; default) ;; zorin) ;;
    *) echo "Unknown Desktop Environment ($DE). Script section skipped" ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

# ── Create /opt/Sanitize and install binary ───────────────────────────────────
# TCM bundles the sanitize binary and is responsible for placing it at the
# canonical system path before creating symlinks or populating /etc/skel.
# Directory: root:lastos-users 775  Binary: root:lastos-users 755
SCRIPT_DIR=$PWD
sudo mkdir -p /opt/Sanitize
sudo cp -f "./sanitize" /opt/Sanitize/sanitize
sudo cp -f "./Removes.ini" /opt/Sanitize/Removes.ini
sudo cp -f ./sanitize.png "/opt/Sanitize/sanitize.png"
sudo chown -R root:lastos-users /opt/Sanitize
sudo chmod -R 775 /opt/Sanitize
echo "Installed binary → /opt/Sanitize/sanitize"

# ── Install sanitize symlink into /etc/skel and /root ─────────────────────────
# The sanitize binary lives at /opt/Sanitize/sanitize (system-wide).
# A symlink pointing to that absolute path is safe in /etc/skel — useradd
# copies it verbatim and the target resolves correctly for every new user.

for DEST in /etc/skel /root; do
    sudo mkdir -p "${DEST}/.local/bin" \
                  "${DEST}/.config/sanitizer" \
                  "${DEST}/.local/share/icons/hicolor/256x256/apps" \
                  "${DEST}/.local/share/icons"

    # Icon — real file named sanitize.png (lowercase); icon lookup is case-sensitive
    sudo cp -f ./sanitize.png "${DEST}/.local/share/icons/hicolor/256x256/apps/sanitize.png"
    sudo cp -f ./sanitize.png "${DEST}/.local/share/icons/sanitize.png"

    # Symlink ~/.local/bin/sanitize → /opt/Sanitize/sanitize
    sudo ln -sf /opt/Sanitize/sanitize "${DEST}/.local/bin/sanitize"

    # Config (don't overwrite if already customised)
    if ! sudo test -f "${DEST}/.config/sanitizer/Removes.ini"; then
        sudo cp -f ./Removes.ini "${DEST}/.config/sanitizer/Removes.ini"
    fi

    echo "Sanitize symlink installed to ${DEST}/.local/bin/sanitize → /opt/Sanitize/sanitize"
done

# ── Copy all skel files (nemo actions, PeaZip scripts, actions-tree, icons) ───
sudo cp -rf ./skel/. /etc/skel/
sudo find /etc/skel/.local/share/nemo/actions/action_scripts -type f -exec chmod +x {} \; 2>/dev/null || true
sudo find /etc/skel/.local/share/nautilus/scripts            -type f -exec chmod +x {} \; 2>/dev/null || true
sudo find /etc/skel/.config/caja/scripts                     -type f -exec chmod +x {} \; 2>/dev/null || true
echo "Copied skel/ → /etc/skel"

sudo cp -rf ./skel/. /root/
sudo find /root/.local/share/nemo/actions/action_scripts -type f -exec chmod +x {} \; 2>/dev/null || true
sudo find /root/.local/share/nautilus/scripts            -type f -exec chmod +x {} \; 2>/dev/null || true
sudo find /root/.config/caja/scripts                     -type f -exec chmod +x {} \; 2>/dev/null || true
echo "Copied skel/ → /root"

# ── Patch /etc/skel actions-tree.json ─────────────────────────────────────────
SKEL_TREE="/etc/skel/.config/nemo/actions-tree.json"
if command -v jq &>/dev/null && sudo test -f "$SKEL_TREE"; then
    PEAZIP_MENU_JSON='{
  "uuid": "PeaZip",
  "type": "submenu",
  "user-label": "PeaZip",
  "user-icon": "peazip",
  "children": [
    {"uuid": "PeaZip, add to archive.nemo_action",  "type": "action", "user-label": null, "user-icon": null},
    {"uuid": "PeaZip, extract archive .nemo_action", "type": "action", "user-label": null, "user-icon": null},
    {"uuid": "PeaZip, extract here.nemo_action",     "type": "action", "user-label": null, "user-icon": null},
    {"uuid": "PeaZip, open as archive.nemo_action",  "type": "action", "user-label": null, "user-icon": null},
    {"uuid": "PeaZip, test.nemo_action",             "type": "action", "user-label": null, "user-icon": null}
  ]
}'
    sudo bash -c "
        jq --argjson pz '$PEAZIP_MENU_JSON' '
          .toplevel |= map(
            if .uuid == \"lastos-sanitize.nemo_action\" then .uuid = \"sanitize.nemo_action\" else . end
          )
          | .toplevel |= (
              if map(.uuid == \"PeaZip\") | any then .
              else . + [\$pz]
              end
            )
        ' \"$SKEL_TREE\" > \"${SKEL_TREE}.tmp\" && mv \"${SKEL_TREE}.tmp\" \"$SKEL_TREE\"
    "
    echo "Patched /etc/skel actions-tree.json"
fi

exit 0