#!/bin/bash

#Get Best Terminal
terms=(gnome-terminal konsole x-terminal-emulator xterm xfce4-terminal)
for t in ${terms[*]}
do
    if [ $(command -v $t) ]
    then
        OSTERM=$t
        break
    fi
done

#Get Package Manager
APT_CMD=$(which apt 2>/dev/null)
DNF_CMD=$(which dnf 2>/dev/null)
EMERGE_CMD=$(which emerge 2>/dev/null)
EOPKG_CMD=$(which eopkg 2>/dev/null)
APK_CMD=$(which apk 2>/dev/null)
PACMAN_CMD=$(which pacman 2>/dev/null)
ZYPPER_CMD=$(which zypper 2>/dev/null)
YUM_CMD=$(which yum 2>/dev/null)


#Get Desktop Environmentto do tasks
echo "Terminal Used: $OSTERM"
echo "Desktop Environment: $XDG_SESSION_DESKTOP"

#Use below sections to put update/upgrade repository or add PPA or repo's
PM=""
if [[ ! -z $APT_CMD ]]; then #apt
    echo "Package Manager: apt"
    PM=apt
    #sudo apt -qq update -y 
    #sudo apt upgrade -y
elif [[ ! -z $DNF_CMD ]]; then #dnf
    PM=dnf
    echo "Package Manager: dnf"
elif [[ ! -z $EMERGE_CMD ]]; then #emerge
    PM=emerge
    echo "Package Manager: emerge"
elif [[ ! -z $EOPKG_CMD ]]; then
    PM=eopkg
    echo "Package Manager: eopkg"
elif [[ ! -z $APK_CMD ]]; then #apk
    PM=apk
    echo "Package Manager: apk"
elif [[ ! -z $PACMAN_CMD ]]; then #pacman
    PM=pacman
    echo "Package Manager: pacman"
elif [[ ! -z $ZYPPER_CMD ]]; then #zypper
    PM=zypper
    echo "Package Manager: zypper"
elif [[ ! -z $YUM_CMD ]]; then #yum
    PM=yum
    echo "Package Manager: yum"
else
    echo "Package Manager: none configured"
fi


#Get OS ID and do things depending on which one
. /etc/os-release

echo "OS ID: $ID"

case $ID in
  linuxmint|ubuntu)
    echo "UBUNTU_CODENAME: $UBUNTU_CODENAME"
    ;;

  debian|pop)
    CODENAME=$(dpkg --status tzdata|grep Provides|cut -f2 -d'-')
    echo "CODENAME: $CODENAME"
    ;;

  fedora)
    CODENAME=$VERSION_ID
    echo "Version ID: $CODENAME"
    #Add Repo
        ;;

  opensuse-tumbleweed)
    ;;

  arch|endeavouros)
    ;;

  solus)
    ;;

  *) 
    echo "This is an unknown distribution."
      ;;
esac

#Do tasks for each Desktop Environment
case $XDG_SESSION_DESKTOP in

  cinnamon)
    ;;

  gnome|ubuntu)
    ;;
  
  kde|KDE)
    ;;

  lxde)
    ;;

  mate)
    ;;
  
  unity)
    ;;

  xfce)
    ;;

  cosmic|pop)
    ;;

  budgie-desktop)
    ;;

  LXQt)
    ;;

  *)
    echo "This is an unknown desktop environment."
    ;;
esac

#Setup Mono and Gecko -REMOVED .msi files FOR SIZE SAVING, downloads each install instead.

if [ -f $HOME/.cache/wine/wine-mono-9.4.0-x86.msi ]; then
    echo "File exists, skip."
else
    if [ -f wine/wine-mono-9.4.0-x86.msi ]; then
        mkdir -p $HOME/.cache/wine
        cp "wine/wine-mono-9.4.0-x86.msi" "$HOME/.cache/wine/"
    else
        echo "Downloading WINE Mono and Gecko, please wait..."      
        wget "https://dl.winehq.org/wine/wine-mono/9.4.0/wine-mono-9.4.0-x86.msi"
        mkdir -p $HOME/.cache/wine

        mv "./wine-mono-9.4.0-x86.msi" "$HOME/.cache/wine/"

    fi
fi


if [ -f $HOME/.cache/wine/wine-gecko-2.47.4-x86.msi ]; then
    echo "File exists, skip."
else
    if [ -f wine/wine-gecko-2.47.4-x86.msi ]; then
        mkdir -p $HOME/.cache/wine
        cp "wine/wine-gecko-2.47.4-x86.msi" "$HOME/.cache/wine/"
    else
        echo "Downloading WINE Gecko, please wait..."      
        wget "https://dl.winehq.org/wine/wine-gecko/2.47.4/wine-gecko-2.47.4-x86.msi"
        mkdir -p $HOME/.cache/wine

        mv "./wine-gecko-2.47.4-x86.msi" "$HOME/.cache/wine/"

    fi
fi


if [ -f $HOME/.cache/wine/wine-gecko-2.47.4-x86_64.msi ]; then
    echo "File exists, skip."
else
    if [ -f wine/wine-gecko-2.47.4-x86_64.msi ]; then
        mkdir -p $HOME/.cache/wine
        cp "wine/wine-gecko-2.47.4-x86_64.msi" "$HOME/.cache/wine/"
    else
        echo "Downloading WINE Mono and Gecko, please wait..."      
        wget "https://dl.winehq.org/wine/wine-gecko/2.47.4/wine-gecko-2.47.4-x86_64.msi"
        mkdir -p $HOME/.cache/wine

        mv "./wine-gecko-2.47.4-x86_64.msi" "$HOME/.cache/wine/"

    fi
fi


if [ -f /tmp/LastOSLinux-Builder ]; then
    echo "Building OS to capture, skipping."
else
    #Configure Wine Silent
    wine wineboot

    echo "Installing WINE Mono and Gecko, please wait..."
    wine "$HOME/.cache/wine/wine-mono-9.4.0-x86.msi"
    wine "$HOME/.cache/wine/wine-gecko-2.47.4-x86.msi"
    wine "$HOME/.cache/wine/wine-gecko-2.47.4-x86_64.msi"
    
    ##Install Fonts needed for games etc
    wine "/LastOS/Scripts-Wine/Fonts.exe"

    #Apply Reg Tweaks
    wine regedit /s "/LastOS/Scripts-Wine/LastOS-Tweaks.reg"
fi

#Make a Link to WINE C Drive in Places/Bookmarks
grep -qF '/.wine/drive_c' ~/.config/gtk-3.0/bookmarks || echo file://$HOME/.wine/drive_c C:\\ \(Wine\) >> ~/.config/gtk-3.0/bookmarks