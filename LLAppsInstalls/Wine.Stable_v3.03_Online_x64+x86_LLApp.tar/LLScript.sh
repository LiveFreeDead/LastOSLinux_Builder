#!/bin/bash

#LLStore Script v1.02

#---------- User Set Variables ----------

# (Add any variables your script needs here before the core loads)

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

# Source shared core: functions (flatinst), terminal/OS detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Core.sh" ]; then source "%ToolPath%/LLScript_Core.sh"; elif [ -f "/LastOS/LLStore/Tools/LLScript_Core.sh" ]; then source "/LastOS/LLStore/Tools/LLScript_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$XDG_SESSION_DESKTOP" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($XDG_SESSION_DESKTOP). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# To install user Flatpaks (no sudo required):
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

#Get Best Terminal
terms=(gnome-terminal konsole x-terminal-emulator xterm xfce4-terminal)
for t in ${terms[*]}
do
    if [ $(command -v $t) ]
    then
        OSTERM=$t
        break
    fi
done

#Get Desktop Environment to do tasks
echo "Terminal Used: $OSTERM"
echo "Desktop Environment: $XDG_SESSION_DESKTOP"

#Do Tasks For Detected OS
. /etc/os-release

echo "OS ID: $ID"

case $ID in
  linuxmint|ubuntu) 
    ;;

  debian|pop)
    ;;

  fedora|nobara) 
    ;;

  opensuse-tumbleweed) 
    ;;

  almalinux)
    ;;

  arch|endeavouros)
    ;;

  argent)
    ;;

  biglinux)
    ;;

  cachyos)
    ;;

  deepin)
    ;;

  garuda)
    ;;

  regataos)
    ;;

  solus)
    ;;

  zorin)
    ;;

  *) 
    echo "Unknown Distribution. Script section skipped"
    ;;
esac

#Do Tasks For Active Desktop Environment
case $XDG_SESSION_DESKTOP in
  cinnamon|cinnamon-wayland|cinnamon2d)
    ;;

  gnome|ubuntu|ubuntu-xorg)
    ;;

  kde|KDE)
    ;;

  lxde)
    ;;

  mate|lightdm-xsession)
    ;;

  unity)
    ;;

  xfce)
    ;;

  cosmic|COSMIC|pop)
    ;;

  budgie-desktop)
    ;;

  LXQt)
    ;;

  anduinos|anduinos-xorg)
    ;;

  deepin)
    ;;

  default)
    ;;

  zorin)
    ;;

  *)
    echo "Unknown Desktop Environment. Script section skipped"
    ;;
esac

#FlatPak Install Package for User
#Add "org.name.thing" to end of line in quote below and unremark to install a Flatpak
#$OSTERM -e "flatpak install --user -y --noninteractive flathub "  # NOTE: could not auto-convert flatpak line – check manually

#----- Add Your Code Here ------

#Setup Mono and Gecko -REMOVED .msi files FOR SIZE SAVING, downloads each install instead.

#if [ -f $HOME/.cache/wine/wine-mono-9.4.0-x86.msi ]; then
#    echo "File exists, skip."
#else
#    if [ -f wine/wine-mono-9.4.0-x86.msi ]; then
#        mkdir -p $HOME/.cache/wine
#        cp "wine/wine-mono-9.4.0-x86.msi" "$HOME/.cache/wine/"
#    else
#        echo "Downloading WINE Mono and Gecko, please wait..."      
#        wget "https://dl.winehq.org/wine/wine-mono/9.4.0/wine-mono-9.4.0-x86.msi"
#        mkdir -p $HOME/.cache/wine
#
#        mv "./wine-mono-9.4.0-x86.msi" "$HOME/.cache/wine/"
#
#    fi
#fi

if [ -f $HOME/.cache/wine/wine-mono-10.4.0-x86.msi ]; then
    echo "File exists, skip."
else
    if [ -f wine/wine-mono-10.4.0-x86.msi ]; then
        mkdir -p $HOME/.cache/wine
        cp "wine/wine-mono-10.4.0-x86.msi" "$HOME/.cache/wine/"
    else
        echo "Downloading WINE Mono and Gecko, please wait..."      
        wget "https://dl.winehq.org/wine/wine-mono/10.4.0/wine-mono-10.4.0-x86.msi"
        mkdir -p $HOME/.cache/wine

        mv "./wine-mono-10.4.0-x86.msi" "$HOME/.cache/wine/"

    fi
fi

if [ -f $HOME/.cache/wine/wine-gecko-2.47.4-x86.msi ]; then
    echo "File exists, skip."
else
    if [ -f wine/wine-gecko-2.47.4-x86.msi ]; then
        mkdir -p $HOME/.cache/wine
        cp "wine/wine-gecko-2.47.4-x86.msi" "$HOME/.cache/wine/"
    else
        echo "Downloading WINE Gecko, please wait..."      
        wget "https://dl.winehq.org/wine/wine-gecko/2.47.4/wine-gecko-2.47.4-x86.msi"
        mkdir -p $HOME/.cache/wine

        mv "./wine-gecko-2.47.4-x86.msi" "$HOME/.cache/wine/"

    fi
fi

if [ -f $HOME/.cache/wine/wine-gecko-2.47.4-x86_64.msi ]; then
    echo "File exists, skip."
else
    if [ -f wine/wine-gecko-2.47.4-x86_64.msi ]; then
        mkdir -p $HOME/.cache/wine
        cp "wine/wine-gecko-2.47.4-x86_64.msi" "$HOME/.cache/wine/"
    else
        echo "Downloading WINE Mono and Gecko, please wait..."      
        wget "https://dl.winehq.org/wine/wine-gecko/2.47.4/wine-gecko-2.47.4-x86_64.msi"
        mkdir -p $HOME/.cache/wine

        mv "./wine-gecko-2.47.4-x86_64.msi" "$HOME/.cache/wine/"

    fi
fi

if [ -f /tmp/LastOSLinux-Builder ]; then
    echo "Building OS to capture, skipping."
else
    #Configure Wine Silent
    wine wineboot

    echo "Installing WINE Mono and Gecko, please wait..."
    wine "$HOME/.cache/wine/wine-mono-10.4.0-x86.msi"
    wine "$HOME/.cache/wine/wine-gecko-2.47.4-x86.msi"
    wine "$HOME/.cache/wine/wine-gecko-2.47.4-x86_64.msi"

    ##Install Fonts needed for games etc
    wine "/LastOS/Scripts-Wine/Fonts.exe"

    #Apply Reg Tweaks
    wine regedit /s "/LastOS/Scripts-Wine/LastOS-Tweaks.reg"
fi

#Make a Link to WINE C Drive in Places/Bookmarks
grep -qF '/.wine/drive_c' ~/.config/gtk-3.0/bookmarks || echo file://$HOME/.wine/drive_c C:\\ \(Wine\) >> ~/.config/gtk-3.0/bookmarks

exit 0