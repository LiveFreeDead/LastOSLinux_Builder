#!/bin/bash

# 1. Get the raw Exec line and strip common desktop flags (%U, %f, etc.)
# We also remove quotes so they don't mess up our path finding
RAW_LINE=$(grep '^Exec=' "$1" | tail -1 | sed -e 's/^Exec=//' -e 's/ %[a-zA-Z]//g' | tr -d '"')

# 2. Filter out 'env' and 'VARIABLE=VALUE' prefixes
# This loop looks at each word and skips it if it looks like an environment setup
FINAL_CMD=""
for arg in $RAW_LINE; do
    if [[ "$arg" == "env" ]] || [[ "$arg" == *=* ]]; then
        continue
    else
        # The first word that isn't 'env' or 'VAR=' is our executable
        FINAL_CMD="$arg"
        break
    fi
done

# 3. Resolve the path
if [[ "$FINAL_CMD" == /* ]]; then
    FULL_PATH="$FINAL_CMD"
else
    FULL_PATH=$(which "$FINAL_CMD")
fi

# 4. Final check and resolution
if [ -z "$FULL_PATH" ] || [ ! -e "$FULL_PATH" ]; then
    notify-send "Location Not Found" "Could not find executable for: $FINAL_CMD"
    exit 1
fi

# Follow symlinks to the source (e.g. /usr/bin/python3 -> /usr/bin/python3.10)
REAL_PATH=$(realpath "$FULL_PATH")

# 5. Open Nemo and highlight
nemo "$REAL_PATH"
