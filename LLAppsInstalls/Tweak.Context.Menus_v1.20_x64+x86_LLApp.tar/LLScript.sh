#!/bin/bash

#LLStore Script v1.02

#---------- User Set Variables ----------

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

if [ -f "%ToolPath%/LLScript_Core.sh" ]; then source "%ToolPath%/LLScript_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
case "$ID" in
    manjaro) ;;
    linuxmint|ubuntu) ;;
    debian|pop) ;;
    fedora|nobara) ;;
    opensuse-tumbleweed|opensuse-leap) ;;
    almalinux) ;;
    arch|endeavouros) ;;
    argent) ;;
    biglinux) ;;
    cachyos) ;;
    deepin) ;;
    garuda) ;;
    regataos) ;;
    solus) ;;
    zorin) ;;
    bazzite|silverblue|kinoite|sericea|aurora|bluefin) ;;
    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$XDG_SESSION_DESKTOP" in
    *[Cc]innamon*)
        cp -rf ./nemo/. $HOME/.local/share/nemo/
        ;;

    gnome|ubuntu|ubuntu-xorg) ;;
    kde|KDE|plasma) ;;
    lxde) ;;
    mate|lightdm-xsession) ;;
    unity) ;;
    xfce) ;;
    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop) ;;
    budgie-desktop) ;;
    LXQt) ;;
    anduinos|anduinos-xorg) ;;
    deepin) ;;
    default) ;;
    zorin) ;;
    *)
        echo "Unknown Desktop Environment ($XDG_SESSION_DESKTOP). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

# ── Install sanitize symlink ───────────────────────────────────────────────────
# The sanitize binary lives at /opt/Sanitize/sanitize — installed to that path
# by this package's LLScript_Sudo.sh. Create a symlink in ~/.local/bin/ so it
# is on PATH for all context menu action_scripts calls.
mkdir -p "$HOME/.local/bin" \
         "$HOME/.local/share/icons/hicolor/256x256/apps" \
         "$HOME/.local/share/icons"

# Icon — install as sanitize.png (lowercase); icon lookup is case-sensitive
cp -f ./sanitize.png "$HOME/.local/share/icons/hicolor/256x256/apps/sanitize.png"
cp -f ./sanitize.png "$HOME/.local/share/icons/sanitize.png"
gtk-update-icon-cache -f -t "$HOME/.local/share/icons/hicolor" 2>/dev/null || true

if [[ -x /opt/Sanitize/sanitize ]]; then
    ln -sf /opt/Sanitize/sanitize "$HOME/.local/bin/sanitize"
    echo "Symlinked → $HOME/.local/bin/sanitize → /opt/Sanitize/sanitize"
else
    echo "WARNING: /opt/Sanitize/sanitize not found — symlink skipped."
    echo "         LLScript_Sudo.sh should have created it first."
fi

# Write config only if not already present (don't overwrite user-customised Removes.ini)
mkdir -p "$HOME/.config/sanitizer"
if [[ ! -f "$HOME/.config/sanitizer/Removes.ini" ]]; then
    cp -f ./Removes.ini "$HOME/.config/sanitizer/Removes.ini"
fi

# ── Copy skel files ────────────────────────────────────────────────────────────
cp -rf ./skel/. $HOME/

# Ensure scripts are executable after copy
find "$HOME/.local/share/nautilus/scripts/PeaZip" -type f -exec chmod +x {} \; 2>/dev/null || true
find "$HOME/.config/caja/scripts/PeaZip"          -type f -exec chmod +x {} \; 2>/dev/null || true
chmod +x "$HOME/.local/share/nemo/actions/action_scripts/sanitize.sh" 2>/dev/null || true
# KDE Plasma 5.22+ requires service menu .desktop files to be executable or
# Dolphin shows "You are not authorized to execute this file"
chmod +x "$HOME/.local/share/kio/servicemenus/LastOS-Tools-actions_servicemenu.desktop" 2>/dev/null || true
chmod +x "$HOME/.local/share/kservices5/ServiceMenus/LastOS-Tools-actions_servicemenu.desktop" 2>/dev/null || true

# ── Patch actions-tree.json ────────────────────────────────────────────────────
# Renames legacy lastos-sanitize UUID → sanitize.nemo_action for existing users
# and adds PeaZip submenu if absent.
ACTIONS_TREE_FILE="$HOME/.config/nemo/actions-tree.json"

if [[ ! -f "$ACTIONS_TREE_FILE" ]]; then
    mkdir -p "$(dirname "$ACTIONS_TREE_FILE")"
    echo '{"toplevel": []}' | jq . > "$ACTIONS_TREE_FILE"
fi

PEAZIP_MENU_JSON='{
  "uuid": "PeaZip",
  "type": "submenu",
  "user-label": "PeaZip",
  "user-icon": "peazip",
  "children": [
    {"uuid": "PeaZip, add to archive.nemo_action",  "type": "action", "user-label": null, "user-icon": null},
    {"uuid": "PeaZip, extract archive .nemo_action", "type": "action", "user-label": null, "user-icon": null},
    {"uuid": "PeaZip, extract here.nemo_action",     "type": "action", "user-label": null, "user-icon": null},
    {"uuid": "PeaZip, open as archive.nemo_action",  "type": "action", "user-label": null, "user-icon": null},
    {"uuid": "PeaZip, test.nemo_action",             "type": "action", "user-label": null, "user-icon": null}
  ]
}'

jq --argjson pz "$PEAZIP_MENU_JSON" '
  .toplevel |= map(
    if .uuid == "lastos-sanitize.nemo_action" then .uuid = "sanitize.nemo_action" else . end
  )
  | .toplevel |= (
      if map(.uuid == "PeaZip") | any then .
      else . + [$pz]
      end
    )
' "$ACTIONS_TREE_FILE" > "$ACTIONS_TREE_FILE.tmp" \
  && mv "$ACTIONS_TREE_FILE.tmp" "$ACTIONS_TREE_FILE"

echo "actions-tree.json updated."

exit 0