#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

# Set to true to reinstall packages even if already installed (useful for fixing broken installs)
FORCE_REINSTALL=false

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
        ;;

    dnf)
        ;;

    apt)
#    #Installing fonts will crash the LLStore
#    ##Microsoft Fonts (EULA bypassed)
#    echo ttf-mscorefonts-installer msttcorefonts/accepted-mscorefonts-eula select true | sudo debconf-set-selections
#    echo fonts-wine msttcorefonts/accepted-mscorefonts-eula select true | sudo debconf-set-selections
#    #Install Apps - using Inst function to work on many Distro's and if packages available on it's repositories.
#    inst ttf-mscorefonts-installer
#    inst fonts-wine
    echo "Marking all installed packages as 'Manual' to prevent accidental removal..."
    # We use -qq to keep the output clean during the build process
    sudo apt-mark manual $(apt-mark showauto) > /dev/null 2>&1
    echo "System is now locked. No packages will be autoremoved."
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        ;;

    zypper)
        ;;

    yum)
        ;;

    emerge)
        ;;

    eopkg)
        ;;

    apk)
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
    echo "UBUNTU_CODENAME: $UBUNTU_CODENAME"
    #Add Wine Repo
    sudo mkdir -pm755 /etc/apt/keyrings
    sudo wget -O /etc/apt/keyrings/winehq-archive.key https://dl.winehq.org/wine-builds/winehq.key
    sudo wget -NP /etc/apt/sources.list.d/ https://dl.winehq.org/wine-builds/ubuntu/dists/$UBUNTU_CODENAME/winehq-$UBUNTU_CODENAME.sources

    #Make sure i386 is enabled
    sudo dpkg --add-architecture i386

    #Update repo's
    sudo apt -qq update -y 
    #sudo apt upgrade -y # No need to do system upgrade just to install wine

    sudo apt install --yes --install-recommends winehq-stable
    #Devel causes issues, just use stable
    #winehq-devel
#The next line shouldn't be needed in v11 as it includes the wow64
    #inst wine32:i386
    #Disable fonts as they crash the installer
    ##Microsoft Fonts (Needs EULA bypassed) Do this before I copy the windows versions over the top
    #echo ttf-mscorefonts-installer msttcorefonts/accepted-mscorefonts-eula select true | sudo debconf-set-selections
    #sudo apt install -y ttf-mscorefonts-installer
        ;;

    debian|pop)
    CODENAME=$(dpkg --status tzdata|grep Provides|cut -f2 -d'-')
    echo "CODENAME: $CODENAME"

    #Add Wine Repo
    sudo dpkg --add-architecture i386 && sudo apt update
    sudo mkdir -pm755 /etc/apt/keyrings
    sudo wget -O /etc/apt/keyrings/winehq-archive.key https://dl.winehq.org/wine-builds/winehq.key
    sudo wget -NP /etc/apt/sources.list.d/ https://dl.winehq.org/wine-builds/debian/dists/$CODENAME/winehq-$CODENAME.sources
    sudo apt -y install --install-recommends winehq-stable

#    inst wine
 #   inst wine32:i386
        ;;

    fedora|nobara)
    CODENAME=$VERSION_ID
    echo "Version ID: $CODENAME"
    #Add Repo
    sudo dnf config-manager addrepo --from-repofile=https://dl.winehq.org/wine-builds/fedora/$CODENAME/winehq.repo
    inst winehq-stable
    #inst wine
    #inst wine32:i386
    #inst wine32:i686
        ;;

    opensuse-tumbleweed)
    if [ "$ID" == "opensuse-tumbleweed" ]; then
        zypper --non-interactive --quiet addrepo -C https://download.opensuse.org/repositories/Emulators:Wine/openSUSE_Tumbleweed/Emulators:Wine.repo
    fi
    if [ "$ID" == "tumbleweed" ]; then
        zypper --non-interactive --quiet addrepo -C https://download.opensuse.org/repositories/Emulators:Wine/Tumbleweed/Emulators:Wine.repo
    fi
    zypper refresh

    inst wine
    inst wine32:i386
    inst wine32:i686
        ;;

    almalinux)
    inst wine
    inst wine32:i386
    inst wine32:i686
        ;;

    arch|endeavouros)
    inst wine
    inst wine32:i386
    inst wine32:i686
        ;;

    argent)
    inst wine
    inst wine32:i386
    inst wine32:i686
        ;;

    biglinux)
    inst wine
    inst wine32:i386
    inst wine32:i686
        ;;

    cachyos)
    inst wine
    inst wine32:i386
    inst wine32:i686
        ;;

    deepin)
    inst wine
    inst wine32:i386
    inst wine32:i686
        ;;

    garuda)
    inst wine
    inst wine32:i386
    inst wine32:i686
        ;;

    regataos)
    inst wine
    inst wine32:i386
    inst wine32:i686
        ;;

    solus)
    inst wine
    inst wine32:i386
    inst wine32:i686
        ;;

    zorin)
    inst wine
    inst wine32:i386
    inst wine32:i686
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------
inst winetricks
inst protontricks
inst wine-desktop-files
inst exe-thumbnailer
inst wine-binfmt
inst binfmt-support
inst wine-mono
inst wine-gecko

#extract .desktop files to make links
sudo tar -xvf ./Overlay.tar -C / --no-same-owner

# --- GLOBAL PROTECTION SHIELD ---
# This ensures that NO package currently in your build is considered an 'orphan'.
# This protects Wine, GStreamer, LLStore, and all system libraries.
if [[ ! -z $APT_CMD ]]; then
    echo "Marking all installed packages as 'Manual' to prevent accidental removal..."
    # We use -qq to keep the output clean during the build process
    sudo apt-mark manual $(apt-mark showauto) > /dev/null 2>&1
    echo "System is now locked. No packages will be autoremoved."
fi

exit 0