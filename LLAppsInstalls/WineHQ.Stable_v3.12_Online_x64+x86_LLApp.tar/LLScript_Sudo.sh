#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

# Set to true to reinstall packages even if already installed (useful for fixing broken installs)
FORCE_REINSTALL=false

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
        ;;

    dnf)
        ;;

    apt)
        # Debian/Ubuntu-specific Wine companion packages
        inst wine
        inst wine-desktop-files
        inst exe-thumbnailer
        inst wine-binfmt
        inst binfmt-support
        inst wine-mono
        inst wine-gecko
        echo "Marking all installed packages as 'Manual' to prevent accidental removal..."
        sudo apt-mark manual $(apt-mark showauto) > /dev/null 2>&1
        echo "System is now locked. No packages will be autoremoved."
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        ;;

    zypper)
        ;;

    yum)
        ;;

    emerge)
        ;;

    eopkg)
        ;;

    apk)
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu|zorin|regataos)
        echo "UBUNTU_CODENAME: $UBUNTU_CODENAME"
        sudo dpkg --add-architecture i386
        sudo mkdir -pm755 /etc/apt/keyrings
        sudo wget -q -O /etc/apt/keyrings/winehq-archive.key https://dl.winehq.org/wine-builds/winehq.key
        sudo wget -qNP /etc/apt/sources.list.d/ https://dl.winehq.org/wine-builds/ubuntu/dists/$UBUNTU_CODENAME/winehq-$UBUNTU_CODENAME.sources
        sudo apt -qq update -y
        sudo apt install --yes --install-recommends winehq-stable
        ;;

    debian|pop|deepin)
        CODENAME=$(dpkg --status tzdata|grep Provides|cut -f2 -d'-')
        echo "CODENAME: $CODENAME"
        sudo dpkg --add-architecture i386 && sudo apt update
        sudo mkdir -pm755 /etc/apt/keyrings
        sudo wget -q -O /etc/apt/keyrings/winehq-archive.key https://dl.winehq.org/wine-builds/winehq.key
        sudo wget -qNP /etc/apt/sources.list.d/ https://dl.winehq.org/wine-builds/debian/dists/$CODENAME/winehq-$CODENAME.sources
        sudo apt -y install --install-recommends winehq-stable
        ;;

    fedora|nobara)
        CODENAME=$VERSION_ID
        echo "Version ID: $CODENAME"
        sudo dnf config-manager addrepo --from-repofile=https://dl.winehq.org/wine-builds/fedora/$CODENAME/winehq.repo
        inst winehq-stable
        ;;

    opensuse-tumbleweed)
        zypper --non-interactive --quiet addrepo -C https://download.opensuse.org/repositories/Emulators:Wine/openSUSE_Tumbleweed/Emulators:Wine.repo
        zypper --non-interactive refresh
        inst wine
        inst wine-32bit
        ;;

    almalinux)
        echo "Version ID: $VERSION_ID"
        sudo dnf config-manager addrepo --from-repofile=https://dl.winehq.org/wine-builds/rhel/$VERSION_ID/winehq.repo
        inst winehq-stable
        ;;

    arch|endeavouros)
        # Wine on Arch includes WoW64 (32-bit support built-in since Wine 8)
        inst wine
        ;;

    argent|biglinux|cachyos|garuda)
        # Arch-based distros – WoW64 built-in, no separate wine32 package needed
        inst wine
        ;;

    solus)
        inst wine
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # rpm-ostree via inst() for packages; they require a reboot to activate.
        ;;

    *)
        #Just try anyway, worst case is it works!
        inst wine
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------
# winetricks and protontricks are not available via rpm-ostree on immutable OS
if ! [ "$IMMUTABLE_OS" = "true" ]; then
    inst winetricks
    inst protontricks
fi

# Extract overlay - behaviour differs between normal and immutable OS:
#   Normal OS : /usr/share is writable, extract everything to /
#   Immutable  : /usr/share is read-only; extract only opt/LastOS (writable),
#                skip usr/ entirely, and save Overlay.tar + Scripts-Wine to
#                $HOME/.lltemp2/ so the deferred wineboot autostart can use
#                them after reboot (reboot wipes /tmp, .lltemp2 survives).
if [ "$IMMUTABLE_OS" = "true" ]; then
    echo "Immutable OS: extracting opt/LastOS only (skipping /usr/share - read-only)..."
    sudo tar -xvf Overlay.tar -C / --no-same-owner \
        --exclude='usr' --exclude='./usr' \
        --exclude='etc/xdg' --exclude='./etc/xdg' \
        2>/dev/null || true

    LLTEMP="$HOME/.lltemp2"
    mkdir -p "$LLTEMP"
    chmod 777 "$LLTEMP"
    echo "Staging Overlay.tar to $LLTEMP for post-reboot icon/desktop install..."
    cp Overlay.tar "$LLTEMP/Overlay.tar"
    echo "Staging Scripts-Wine for post-reboot wineboot..."
    mkdir -p "$LLTEMP/Scripts-Wine"
    chmod 777 "$LLTEMP/Scripts-Wine"
    tar -xf Overlay.tar -C "$LLTEMP" opt/LastOS/Scripts-Wine --strip-components=2 --no-same-owner 2>/dev/null || true
    sudo chown -R "$SUDO_USER:$SUDO_USER" "$LLTEMP" 2>/dev/null || true
else
    echo "Extracting overlay to /..."
    sudo tar -xvf Overlay.tar -C / --no-same-owner
fi

exit 0