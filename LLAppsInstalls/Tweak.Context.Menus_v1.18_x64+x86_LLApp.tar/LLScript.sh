#!/bin/bash

#LLStore Script v1.02

#---------- User Set Variables ----------

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

# Source shared core: functions (flatinst), terminal/OS detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Core.sh" ]; then source "%ToolPath%/LLScript_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use $HOME/.local/share/ paths instead of /usr/share/, and note that
        # rpm-ostree installs require a reboot before packages are available.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$XDG_SESSION_DESKTOP" in
    *[Cc]innamon*)
        cp -rf ./nemo/. $HOME/.local/share/nemo/
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        #mkdir $HOME/.config/xfce
        #cp -rf ./xfce4/* $HOME/.config/xfce
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($XDG_SESSION_DESKTOP). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# To install user Flatpaks (no sudo required):
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------
cp -rf ./skel/. $HOME/

#Fix PeaZip expanding after applying this
ACTIONS_TREE_FILE="$HOME/.config/nemo/actions-tree.json"

# The JSON object you want to add, stored in a bash variable.
# The structure uses semicolons to avoid newline characters in the script source file itself,
# while maintaining valid JSON structure when interpreted.
PEAZIP_MENU_JSON='{
  "uuid": "PeaZip",
  "type": "submenu",
  "user-label": "PeaZip",
  "user-icon": "peazip",
  "children": [
    {
      "uuid": "PeaZip, add to archive.nemo_action",
      "type": "action",
      "user-label": null,
      "user-icon": null
    },
    {
      "uuid": "PeaZip, extract archive .nemo_action",
      "type": "action",
      "user-label": null,
      "user-icon": null
    },
    {
      "uuid": "PeaZip, extract here.nemo_action",
      "type": "action",
      "user-label": null,
      "user-icon": null
    },
    {
      "uuid": "PeaZip, open as archive.nemo_action",
      "type": "action",
      "user-label": null,
      "user-icon": null
    },
    {
      "uuid": "PeaZip, test.nemo_action",
      "type": "action",
      "user-label": null,
      "user-icon": null
    }
  ]
}'

# Use jq to conditionally append the object to the "toplevel" array

# Check if actions-tree.json exists, create if not (with basic structure including "toplevel": [])
if [[ ! -f "$ACTIONS_TREE_FILE" ]]; then
    echo '{"toplevel": []}' | jq . > "$ACTIONS_TREE_FILE"
    echo "Created initial actions-tree.json with empty toplevel array."
fi

# Apply the update: check if "PeaZip" uuid exists in "toplevel" children; if not, add it.
jq --argjson new_item "$PEAZIP_MENU_JSON" '
  .toplevel |= (
    if map(.uuid == "PeaZip") | any then
      .
    else
      . + [$new_item]
    end
  )
' "$ACTIONS_TREE_FILE" > "$ACTIONS_TREE_FILE.tmp" && mv "$ACTIONS_TREE_FILE.tmp" "$ACTIONS_TREE_FILE"

echo "Updated $ACTIONS_TREE_FILE if the PeaZip entry was missing."

exit 0