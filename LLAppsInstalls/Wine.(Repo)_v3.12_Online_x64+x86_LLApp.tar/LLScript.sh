#!/bin/bash

#LLStore Script v1.02

#---------- User Set Variables ----------

# (Add any variables your script needs here before the core loads)

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

# Source shared core: functions (flatinst), terminal/OS detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Core.sh" ]; then source "%ToolPath%/LLScript_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$XDG_SESSION_DESKTOP" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($XDG_SESSION_DESKTOP). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# To install user Flatpaks (no sudo required):
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

# Download helper - tries wget first, falls back to curl (Fedora/Nobara ship curl not wget)
_wgdl() {
    local url="$1" dest="$2"
    mkdir -p "$(dirname "$dest")"
    if command -v wget &>/dev/null; then
        wget -q --show-progress -O "$dest" "$url"
    elif command -v curl &>/dev/null; then
        curl -L --progress-bar -o "$dest" "$url"
    else
        echo "Error: wget and curl not found. Cannot download: $(basename "$url")"
        return 1
    fi
}

WINE_CACHE="$HOME/.cache/wine"
mkdir -p "$WINE_CACHE"

if [ ! -f "$WINE_CACHE/wine-mono-11.0.0-x86.msi" ]; then
    echo "Downloading Wine Mono 11.0.0..."
    _wgdl "https://dl.winehq.org/wine/wine-mono/11.0.0/wine-mono-11.0.0-x86.msi" \
          "$WINE_CACHE/wine-mono-11.0.0-x86.msi"
else
    echo "Wine Mono 11.0.0 already cached."
fi

if [ ! -f "$WINE_CACHE/wine-gecko-2.47.4-x86.msi" ]; then
    echo "Downloading Wine Gecko 2.47.4 (x86)..."
    _wgdl "https://dl.winehq.org/wine/wine-gecko/2.47.4/wine-gecko-2.47.4-x86.msi" \
          "$WINE_CACHE/wine-gecko-2.47.4-x86.msi"
else
    echo "Wine Gecko 2.47.4 (x86) already cached."
fi

if [ ! -f "$WINE_CACHE/wine-gecko-2.47.4-x86_64.msi" ]; then
    echo "Downloading Wine Gecko 2.47.4 (x86_64)..."
    _wgdl "https://dl.winehq.org/wine/wine-gecko/2.47.4/wine-gecko-2.47.4-x86_64.msi" \
          "$WINE_CACHE/wine-gecko-2.47.4-x86_64.msi"
else
    echo "Wine Gecko 2.47.4 (x86_64) already cached."
fi

if [ -f /tmp/LastOSLinux-Builder ]; then
    echo "Building OS to capture, skipping."
elif [ "$IMMUTABLE_OS" = "true" ]; then
    # Immutable OS (Bazzite etc.)
    # Wine was just layered via rpm-ostree but won't be available until after a
    # reboot. Defer everything to a one-shot autostart that runs after the
    # user's next login, then cleans itself up.
    echo "Immutable OS detected - Wine requires a reboot before it is available."
    echo "Creating post-reboot wineboot autostart..."

    LLTEMP="$HOME/.lltemp2"
    WINEBOOT_SCRIPT="$LLTEMP/wineboot-script.sh"
    AUTOSTART_DIR="$HOME/.config/autostart"
    AUTOSTART_FILE="$AUTOSTART_DIR/llstore-wineboot.desktop"

    mkdir -p "$LLTEMP"
    mkdir -p "$AUTOSTART_DIR"

    # Copy the pre-built wineboot script from the install package to .lltemp2.
    # It survives reboots there (unlike /tmp) and is already executable.
    cp wineboot-script.sh "$WINEBOOT_SCRIPT"
    chmod +x "$WINEBOOT_SCRIPT"

    # Write and chmod the autostart desktop file so KDE/GNOME will run it on login.
    printf '[Desktop Entry]\nType=Application\nName=LLStore Startup Configure wine\nExec=%s\nHidden=false\nNoDisplay=false\nX-GNOME-Autostart-enabled=true\n' "$WINEBOOT_SCRIPT" > "$AUTOSTART_FILE"
    chmod +x "$AUTOSTART_FILE"

    echo "Wineboot autostart created at: $AUTOSTART_FILE"
    echo "Wine will be fully initialised after your next login."
else
    # Normal distros - run immediately
    echo "Initialising Wine prefix..."
    wine wineboot

    echo "Installing Wine Mono and Gecko..."
    wine "$WINE_CACHE/wine-mono-11.0.0-x86.msi"
    wine "$WINE_CACHE/wine-gecko-2.47.4-x86.msi"
    wine "$WINE_CACHE/wine-gecko-2.47.4-x86_64.msi"

    echo "Installing Fonts..."
    wine "/opt/LastOS/Scripts-Wine/Fonts.exe"

    echo "Applying registry tweaks..."
    wine regedit /s "/opt/LastOS/Scripts-Wine/LastOS-Tweaks.reg"
fi

#Make a Link to WINE C Drive in Places/Bookmarks
grep -qF '/.wine/drive_c' ~/.config/gtk-3.0/bookmarks || echo file://$HOME/.wine/drive_c C:\\ \(Wine\) >> ~/.config/gtk-3.0/bookmarks

exit 0