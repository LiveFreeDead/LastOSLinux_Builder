#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#Pre Script Overlays
#extract themes and icons etc
if [ "$IMMUTABLE_OS" = true ]; then
    mkdir -p "$HOME/.local/"
    tar -xvf ./share.tar -C "$HOME/.local/"
else
    sudo tar -xvf ./share.tar -C /usr/
fi

# Set asset paths based on whether this is an immutable OS
if [ "$IMMUTABLE_OS" = true ]; then
    WALLPAPER_BASE="$HOME/.local/share/backgrounds/lastos"
else
    WALLPAPER_BASE="/usr/share/backgrounds/lastos"
fi
WALLPAPER_PATH="$WALLPAPER_BASE/Wallpaper2.jpg"
LOGIN_PATH="$WALLPAPER_BASE/Login2.jpg"

#Install Mouse Theme
inst dmz-cursor-theme

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
        ;;

    dnf)
        ;;

    apt)
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        ;;

    zypper)
        ;;

    yum)
        ;;

    emerge)
        ;;

    eopkg)
        ;;

    apk)
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use rpm-ostree via inst() for packages; they require a reboot to activate.
        # Avoid writing to /usr/share/ — use $HOME/.local/share/ instead.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
    #Set Dark Theme
    gsettings set org.cinnamon.desktop.interface gtk-theme "Mint-L-Dark-Purple"
    gsettings set org.cinnamon.desktop.interface icon-theme "Yaru-purple-dark"
    gsettings set org.cinnamon.theme name "Mint-L-Dark-Purple"
    gsettings set org.gnome.desktop.interface gtk-theme "Mint-L-Dark-Purple"
    gsettings set org.x.apps.portal color-scheme "prefer-dark"

    sudo gsettings set org.cinnamon.desktop.interface gtk-theme "Mint-L-Dark-Purple"
    sudo gsettings set org.cinnamon.desktop.interface icon-theme "Yaru-purple-dark"
    sudo gsettings set org.cinnamon.theme name "Mint-L-Dark-Purple"
    sudo gsettings set org.gnome.desktop.interface gtk-theme "Mint-L-Dark-Purple"
    sudo gsettings set org.x.apps.portal color-scheme "prefer-dark"

    #Set White Mouse Cursor
    gsettings set org.cinnamon.desktop.interface cursor-theme "DMZ-White"
    gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"
    gsettings set x.dm.slick-greeter cursor-theme-name "DMZ-White"
    sudo gsettings set org.cinnamon.desktop.interface cursor-theme "DMZ-White"
    sudo gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"
    sudo gsettings set x.dm.slick-greeter cursor-theme-name "DMZ-White"

    #Set Wallpaper
    gsettings set org.cinnamon.desktop.background picture-uri "file://$WALLPAPER_PATH"
    sudo gsettings set org.cinnamon.desktop.background picture-uri "file://$WALLPAPER_PATH"

    #Set Login Background
    gsettings set x.dm.slick-greeter background "$LOGIN_PATH"
    sudo gsettings set x.dm.slick-greeter background "$LOGIN_PATH"

    #Set Default WINE Mouse Cursor to DMZ-White
    sudo update-alternatives --set x-cursor-theme /usr/share/icons/DMZ-White/cursor.theme
        ;;

    gnome|ubuntu|ubuntu-xorg)
    #Set Dark Theme
    gsettings set org.gnome.desktop.interface gtk-theme "Mint-L-Dark-Purple"
    gsettings set org.gnome.desktop.interface icon-theme "Yaru-purple-dark"
    gsettings set org.gnome.theme name "Mint-L-Dark-Purple"
    gsettings set org.x.apps.portal color-scheme "prefer-dark"
    gsettings set org.gnome.desktop.interface color-scheme "prefer-dark"
    sudo gsettings set org.gnome.desktop.interface gtk-theme "Mint-L-Dark-Purple"
    sudo gsettings set org.gnome.desktop.interface icon-theme "Yaru-purple-dark"
    sudo gsettings set org.gnome.theme name "Mint-L-Dark-Purple"
    sudo gsettings set org.x.apps.portal color-scheme "prefer-dark"
    sudo gsettings set org.gnome.desktop.interface color-scheme "prefer-dark"

    #Set White Mouse Cursor
    gsettings set org.cinnamon.desktop.interface cursor-theme "DMZ-White"
    gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"
    gsettings set x.dm.slick-greeter cursor-theme-name "DMZ-White"
    sudo gsettings set org.cinnamon.desktop.interface cursor-theme "DMZ-White"
    sudo gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"
    sudo gsettings set x.dm.slick-greeter cursor-theme-name "DMZ-White"

    #Set Wallpaper
    gsettings set org.gnome.desktop.background color-shading-type "solid"
    gsettings set org.gnome.desktop.background picture-options "zoom"
    gsettings set org.gnome.desktop.background picture-uri "file://$WALLPAPER_PATH"
    gsettings set org.gnome.desktop.background picture-uri-dark "file://$WALLPAPER_PATH"
    sudo gsettings set org.gnome.desktop.background color-shading-type "solid"
    sudo gsettings set org.gnome.desktop.background picture-options "zoom"
    sudo gsettings set org.gnome.desktop.background picture-uri "file://$WALLPAPER_PATH"
    sudo gsettings set org.gnome.desktop.background picture-uri-dark "file://$WALLPAPER_PATH"

    #Set Login Background
    gsettings set org.gnome.desktop.screensaver picture-uri "file://$WALLPAPER_PATH"
    sudo gsettings set org.gnome.desktop.screensaver picture-uri "file://$WALLPAPER_PATH"
        ;;

    kde|KDE|plasma)
    lookandfeeltool -a org.kde.breezedark.desktop
    /usr/libexec/plasma-changeicons breeze-dark
    plasma-apply-wallpaperimage "$WALLPAPER_PATH"
    sudo lookandfeeltool -a org.kde.breezedark.desktop
    sudo /usr/libexec/plasma-changeicons breeze-dark
    sudo plasma-apply-wallpaperimage "$WALLPAPER_PATH"
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
    gsettings set org.mate.interface gtk-theme "Mint-L-Dark-Purple"
    gsettings set org.mate.Marco.general theme "Mint-L-Dark-Purple"
    gsettings set org.mate.interface icon-theme "Yaru-purple-dark"
    gsettings set org.mate.peripherals-mouse cursor-theme "DMZ-White"
    #Below doesn't work due to needing a direct installed icon, not a file name.
    #gsettings set org.mate.panel.menubar icon-name "/usr/share/icons/Start Button MATE.png"
    gsettings set org.mate.background picture-filename "$WALLPAPER_PATH"

    sudo gsettings set org.mate.interface gtk-theme "Mint-L-Dark-Purple"
    sudo gsettings set org.mate.Marco.general theme "Mint-L-Dark-Purple"
    sudo gsettings set org.mate.interface icon-theme "Yaru-purple-dark"
    sudo gsettings set org.mate.peripherals-mouse cursor-theme "DMZ-White"
    #Below doesn't work due to needing a direct installed icon, not a file name.
    #sudo gsettings set org.mate.panel.menubar icon-name "/usr/share/icons/Start Button MATE.png"
    sudo gsettings set org.mate.background picture-filename "$WALLPAPER_PATH"
        ;;

    unity)
        ;;

    xfce)
    gsettings set org.gnome.desktop.interface gtk-theme "Mint-L-Dark-Purple"
    gsettings set org.gnome.desktop.interface color-scheme "prefer-dark"
    gsettings set org.gnome.desktop.interface icon-theme "Yaru-purple-dark"
    gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"

    sudo gsettings set org.gnome.desktop.interface gtk-theme "Mint-L-Dark-Purple"
    sudo gsettings set org.gnome.desktop.interface color-scheme "prefer-dark"
    sudo gsettings set org.gnome.desktop.interface icon-theme "Yaru-purple-dark"
    sudo gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------
inst qt5ct adwaita-qt
inst mint-themes
inst mint-l-icons
inst mint-y-icons
inst yaru-theme-icon
inst yaru-theme-gtk

#Update Login Screen to use the right mouse cursor and picture
# Define the target configuration file
CONF_FILE="/etc/lightdm/slick-greeter.conf"

DRAW_USER_BG="false"
CURSOR_THEME="DMZ-White"

# --- Function to update or add a key using sed ---
set_config_key() {
    local key=$1
    local value=$2
    # Check if the key exists and update it, otherwise add it
    if grep -q "^$key=" "$CONF_FILE"; then
        sudo sed -i "s|^$key=.*|$key=$value|" "$CONF_FILE"
    else
        echo "$key=$value" | sudo tee -a "$CONF_FILE" > /dev/null
    fi
}

# Ensure the configuration file and the [Greeter] section exist
if [ ! -f "$CONF_FILE" ]; then
    echo "[Greeter]" | sudo tee "$CONF_FILE" > /dev/null
fi

# Set the background image path
set_config_key "background" "$LOGIN_PATH"

# Ensure user backgrounds are disabled to use the global setting
set_config_key "draw-user-backgrounds" "$DRAW_USER_BG"

# Set the cursor theme for the greeter
set_config_key "cursor-theme-name" "$CURSOR_THEME"

exit 0