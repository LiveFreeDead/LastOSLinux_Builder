#!/bin/bash

#LLStore Script v1.02

#---------- User Set Variables ----------

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

# Source shared core: functions (flatinst), terminal/OS detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Core.sh" ]; then source "%ToolPath%/LLScript_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################


mkdir -p $HOME/.themes/LastOS2-MATE
cp -rf ./LastOS2-MATE $HOME/.themes/

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use $HOME/.local/share/ paths instead of /usr/share/, and note that
        # rpm-ostree installs require a reboot before packages are available.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$XDG_SESSION_DESKTOP" in
    *[Cc]innamon*)
    #Set Dark Theme
    gsettings set org.cinnamon.desktop.interface gtk-theme "Mint-L-Dark-Purple"
    gsettings set org.cinnamon.desktop.interface icon-theme "Yaru-purple-dark"
    gsettings set org.cinnamon.theme name "Mint-L-Dark-Purple"
    gsettings set org.gnome.desktop.interface gtk-theme "Mint-L-Dark-Purple"
    gsettings set org.x.apps.portal color-scheme "prefer-dark"

    #Set White Mouse Cursor
    gsettings set org.cinnamon.desktop.interface cursor-theme "DMZ-White"
    gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"
    gsettings set x.dm.slick-greeter cursor-theme-name "DMZ-White"

    #Set Wallpaper
    gsettings set org.cinnamon.desktop.background picture-uri 'file:///usr/share/backgrounds/lastos/Wallpaper2.jpg'

    #Set Login Background
    gsettings set x.dm.slick-greeter background '/usr/share/backgrounds/lastos/Login2.jpg'

    #Change Main Menu icon to LastOS
    cd $HOME/.config/cinnamon/spices/menu@cinnamon.org/
    grep -lZ '"value": "start-here-symbolic"' 0.json | xargs -0 sed -i 's|"value": "start-here-symbolic"|"value": "linuxmint-logo-ring-symbolic"|g'

    grep -lZ '"value": "linuxmint-logo-ring-symbolic"' 0.json | xargs -0 sed -i 's|"value": "linuxmint-logo-ring-symbolic"|"value": "/usr/share/icons/Start Button.png"|g'

    #Restart Desktop (Let Icon Auto-Arrange be disable for this Session)
    nemo-desktop --quit
    nemo --no-default-window &
        ;;

    gnome|ubuntu|ubuntu-xorg)
    #Set Dark Theme
    gsettings set org.gnome.desktop.interface gtk-theme "Mint-L-Dark-Purple"
    gsettings set org.gnome.desktop.interface icon-theme "Yaru-purple-dark"
    gsettings set org.gnome.theme name "Mint-L-Dark-Purple"
    gsettings set org.x.apps.portal color-scheme "prefer-dark"
    gsettings set org.gnome.desktop.interface color-scheme "prefer-dark"

    #Set White Mouse Cursor
    gsettings set org.cinnamon.desktop.interface cursor-theme "DMZ-White"
    gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"
    gsettings set x.dm.slick-greeter cursor-theme-name "DMZ-White"

    #Set Wallpaper
    gsettings set org.gnome.desktop.background color-shading-type "solid"
    gsettings set org.gnome.desktop.background picture-options "zoom"
    gsettings set org.gnome.desktop.background picture-uri "file:///usr/share/backgrounds/lastos/Wallpaper2.jpg"
    gsettings set org.gnome.desktop.background picture-uri-dark "file:///usr/share/backgrounds/lastos/Wallpaper2.jpg"

    #Set Login Background
    gsettings set org.gnome.desktop.screensaver picture-uri "file:///usr/share/backgrounds/lastos/Wallpaper2.jpg"
        ;;

    kde|KDE|plasma)
    lookandfeeltool -a org.kde.breezedark.desktop
    /usr/libexec/plasma-changeicons breeze-dark
    plasma-apply-wallpaperimage "/usr/share/backgrounds/lastos/Wallpaper2.jpg"
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
    gsettings set org.mate.interface gtk-theme "Mint-L-Dark-Purple"
    gsettings set org.mate.Marco.general theme "Mint-L-Dark-Purple"
    gsettings set org.mate.interface icon-theme "Yaru-purple-dark"
    gsettings set org.mate.peripherals-mouse cursor-theme "DMZ-White"
    #Below doesn't work due to needing a direct installed icon, not a file name.
    #gsettings set org.mate.panel.menubar icon-name "/usr/share/icons/Start Button MATE.png"
    gsettings set org.mate.background picture-filename "/usr/share/backgrounds/lastos/Wallpaper2.jpg"
        ;;

    unity)
        ;;

    xfce)
    gsettings set org.gnome.desktop.interface gtk-theme "Mint-L-Dark-Purple"
    gsettings set org.gnome.desktop.interface color-scheme "prefer-dark"
    gsettings set org.gnome.desktop.interface icon-theme "Yaru-purple-dark"
    gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"

    mkdir $HOME/.config/xfce
    cp -rf ./xfce4/. $HOME/.config/xfce
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        pcmanfm-qt --set-wallpaper=/usr/share/backgrounds/lastos/Wallpaper2.jpg --wallpaper-mode=fit
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($XDG_SESSION_DESKTOP). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# To install user Flatpaks (no sudo required):
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

exit 0