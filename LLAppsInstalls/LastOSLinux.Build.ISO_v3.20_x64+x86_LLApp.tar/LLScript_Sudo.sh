#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

# Set to true to reinstall packages even if already installed (useful for fixing broken installs)
FORCE_REINSTALL=false

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
        ;;

    dnf)
        ;;

    apt)
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        ;;

    zypper)
        ;;

    yum)
        ;;

    emerge)
        ;;

    eopkg)
        ;;

    apk)
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use rpm-ostree via inst() for packages; they require a reboot to activate.
        # Avoid writing to /usr/share/ — use $HOME/.local/share/ instead.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

#---------Copy settings to skel ---------

#show Hidden Files By Default as root user
gsettings set org.nemo.preferences show-hidden-files true
sudo gsettings set org.nemo.preferences show-hidden-files true

#exit 0

sudo mkdir -p /etc/skel/.cache/wine
sudo cp "/home/$SUDO_USER/.cache/wine/"wine-mono-*-x86.msi "/etc/skel/.cache/wine/"
sudo cp "/home/$SUDO_USER/.cache/wine/"wine-gecko-*-x86.msi "/etc/skel/.cache/wine/"
sudo cp "/home/$SUDO_USER/.cache/wine/"wine-gecko-*-x86_64.msi "/etc/skel/.cache/wine/"

MY_USER=$(logname)

# --- SECURITY UPDATE: Create Group and Add User ---
if ! getent group lastos-users > /dev/null; then
    sudo groupadd lastos-users
fi
# Add current user to group
sudo usermod -aG lastos-users "$MY_USER"
# --------------------------------------------------

sudo mkdir -p /etc/skel/.cache/wine
sudo cp "/home/$MY_USER/.cache/wine/"wine-mono-*-x86.msi "/etc/skel/.cache/wine/"
sudo cp "/home/$MY_USER/.cache/wine/"wine-gecko-*-x86.msi "/etc/skel/.cache/wine/"
sudo cp "/home/$MY_USER/.cache/wine/"wine-gecko-*-x86_64.msi "/etc/skel/.cache/wine/"

#Below was for testing
#exit 0

##Remove the users bookmarks as it hardcodes links in the file (this is for live user (TEST IF NEEDED for Live OS)
#sudo rm -f $HOME/.config/gtk-3.0/bookmarks

sudo mkdir -p /etc/skel/.config/

#copy whole lot and remove ones that break things
#sudo cp -R $HOME/.config/* /etc/skel/.config/ #ORIGINAL
sudo cp -R /home/$MY_USER/.config/* /etc/skel/.config/

#Remove the whole folder
### $HOME/.config/gtk-3.0/gtk.css <-First Logon creates this
sudo rm -f /etc/skel/.config/gtk-3.0/bookmarks
sudo rm -Rf /etc/skel/.config/gtk-3.0

sudo rm -f /etc/skel/.config/user-dirs.dirs
sudo rm -f /etc/skel/.config/user-dirs.locale

#Testing this works to remove hardcoded links in said file :)
sudo rm -f /etc/skel/.config/menus/cinnamon-applications-merged

#Correct the permissions for skel (needs RW for root, RW for users and Access for non user)
sudo chmod -R 775 /etc/skel

#root stuff #
#copy skel to root user so custom changes are also applied to root user
#No need to remove things as I do it above for the skel user, same applies to root
sudo cp -rf /etc/skel/* /root
sudo rm -rf /root/.cache/*

# --- FINAL SECURITY HARDENING FOR /opt/LastOS ---
# This ensures that before SquishFS is made, the security permissions are strictly enforced
# on everything in /opt/LastOS, including any subfolders created during the process.
echo "Hardening /opt/LastOS security..."
sudo chown -R root:lastos-users /opt/LastOS
sudo chmod -R 775 /opt/LastOS

# --------------------------------------------

#######Backup the current users LLApps and LLGames, make the .desktop files change current user to lastos, so the firstlogon.sh changes them to the new user name

sudo mkdir -p /opt/LastOS/skel
sudo mkdir -p "/opt/LastOS/skel/LLApps/"
sudo mkdir -p "/opt/LastOS/skel/LLGames/"
sudo mkdir -p "/opt/LastOS/skel/.var/"
sudo mkdir -p "/opt/LastOS/skel/.local/share/flatpak/"

# --- SECURITY FIX: Set Initial Permissions for LastOS ---
sudo chown -R root:lastos-users /opt/LastOS
sudo chmod -R 775 /opt/LastOS
# --------------------------------------------------------

#Ignored hidden stuff and lost executable bits
#sudo cp -R "/home/$MY_USER/LLApps" "/opt/LastOS/skel/"
#sudo cp -R "/home/$MY_USER/LLGames" "/opt/LastOS/skel/"
#sudo cp -R "/home/$MY_USER/.var" "/opt/LastOS/skel/"

#New way uses rsync
sudo rsync -aHAX "/home/$MY_USER/LLApps" "/home/$MY_USER/LLGames" "/home/$MY_USER/.var" /opt/LastOS/skel/

#Test This Works
sudo rsync -aHAX "/home/$MY_USER/.local/share/flatpak" /opt/LastOS/skel/.local/share/


# Re-assert 1001 ownership for skel but keep the group, allows Live and the installed OS to use it
if [ -d "/opt/LastOS/skel" ]; then
    sudo chown -R 1001:lastos-users /opt/LastOS/skel
    sudo chmod -R 777 /opt/LastOS/skel
fi
# --------------------------------------------------

mkdir -p /etc/skel/.local/share/applications
sudo cp -R /home/$MY_USER/.local/share/applications/*.desktop /etc/skel/.local/share/applications/

# Define the target directory
directory="/etc/skel/.local/share/applications"

# Find all .desktop files in the target directory
find "$directory" -type f -name "*.desktop" | while read -r file; do
    ## Backup the original file (optional) Disabled
    #cp "$file" "$file.bak"
    
    # Use sed to replace '$HOME/' with '/home/lastos/' in the file
    # (also fixes absolute Exec=/Icon= paths into ~/Applications and ~/.local/share/icons)
    sudo sed -i "s|/home/$MY_USER|/home/lastos|g" "$file"
    
    # You can also add echo commands to show progress or actions
    #echo "Updated: $file"
done

#echo "All .desktop files have been updated."

#---------- ArtCraft (AppImages) support: icons + ~/Applications to skel ----------
#Done AFTER the 'cp /etc/skel/* /root' above on purpose, so big AppImages don't get copied into /root.
#rsync keeps the executable bit on the AppImages (a plain cp -R from a glob can lose hidden/perm stuff)

#Icons referenced by the .desktop files above
if [ -d "/home/$MY_USER/.local/share/icons" ]; then
    sudo mkdir -p /etc/skel/.local/share/icons
    sudo rsync -aHAX --chown=root:root "/home/$MY_USER/.local/share/icons/" /etc/skel/.local/share/icons/
else
    echo "No /home/$MY_USER/.local/share/icons found, skipping icons copy"
fi

#AppImages (ArtCraft installs them to ~/Applications)
if [ -d "/home/$MY_USER/Applications" ]; then
    sudo mkdir -p /etc/skel/Applications
    sudo rsync -aHAX --chown=root:root "/home/$MY_USER/Applications/" /etc/skel/Applications/
    #Make sure the AppImages stay executable for everyone
    sudo find /etc/skel/Applications -type f -iname "*.AppImage" -exec chmod 755 {} +
else
    echo "No /home/$MY_USER/Applications found, skipping AppImage copy"
fi

#----------------------------------------

#Update Grub
#Make the error level 2 in grub (defaults to 4 in Ubuntu/Mint, 3 is recommended (2 Critical)(3 Error)(4 Warnings)
    sudo grep -lZ 'GRUB_CMDLINE_LINUX_DEFAULT="quiet splash"' /etc/default/grub| sudo xargs -0 sed -i 's|GRUB_CMDLINE_LINUX_DEFAULT="quiet splash"|GRUB_CMDLINE_LINUX_DEFAULT="quiet loglevel=2 splash"|g'
    sudo update-grub


#Remove Leftovers
sudo rm -f /opt/LastOS/LastOSServiceRan.txt
sudo rm -f /boot/*.old
sudo rm -rf /opt/LastOS/Advanced-Nemo-Actions
sudo rm -rf /media/LastOSLinuxUSBBoot
sudo rm -f /opt/LastOS/LLStore/LLL_Store_Linux_Manual_Locations.ini


#Make sure calamares is actually installed (may glitch out if packages are missing or anything).
#Install Calamares installer (It also configures it, but I do it later on as well just in case)
#Don't need sudo as the script is ran as sudo - put it back if fails
inst calamares
sudo eggs calamares -i

#Copy LastOS Service
#Make the sudo service executable and not editable by users
sudo cp -f sudo_firstlogon_service.sh /etc/
sudo chmod 755 "/etc/sudo_firstlogon_service.sh"
sudo chmod +x "/etc/sudo_firstlogon_service.sh"
sudo rm -f "/etc/sudo_firstlogon_service.sh.disabled"

sudo tar xf ./Service-SymLinks.tar -C /


#Change Host name, moved to end of scripts so it doesn't interfere as it seems to make sudo stop working for some things and even changed the calamares to krill
#Fails on Mint v22.2
#hostnamectl set-hostname LastOSLinuxLive



##Copy exclude list again, just in case it gets removed again
#sudo cp -f "./Overlays/etc/penguins-eggs.d/exclude.list" "/etc/penguins-eggs.d/"
#sudo cp -f "./Overlays/usr/lib/penguins-eggs/conf/derivatives.yaml" "/usr/lib/penguins-eggs/conf/"
#
#sudo chmod 775 "/etc/penguins-eggs.d/exclude.list"

#Try to add lastos-users to live user
sudo mkdir -p /etc/penguins-eggs.d/custom
sudo cp -f "./Overlays/etc/penguins-eggs.d/custom/99-add-lastos-group.sh" "/etc/penguins-eggs.d/custom/"



##Copy rc.local again, just in case it gets removed again
#sudo cp -f Overlays/etc/rc.local /etc/
#sudo chmod 775 "/etc/rc.local"

#Fix /lib /etc permissions so the Firewall works
sudo chmod 755 /lib
sudo chmod 755 /etc

##Due to the bug in having dual iso creators, this temp fix makes it work (No Longer needed)
#sudo apt purge -y genisoimage

#Do this last to attempt to fix the Apt Cache issue
sudo apt update -y


#Make the calamares run without user password being required:
# Replace 'live' with your actual live session username if different
LIVEUSER="live"

# Allow Calamares to run without password
echo "$LIVEUSER ALL=(ALL) NOPASSWD: /usr/bin/calamares" > /etc/sudoers.d/calamares
#NO#echo "$LIVEUSER ALL=(ALL) NOPASSWD: /usr/bin/env" > /etc/sudoers.d/env

# Make sure permissions are correct
chmod 440 /etc/sudoers.d/calamares
#NO#chmod 440 /etc/sudoers.d/env

echo "Configured Calamares to not require sudo password for user $LIVEUSER"


#Start The Build

#This line is required to copy calamares-modules across, will fail to install without it
sudo eggs calamares

#Remove genisoimage
sudo apt remove -y genisoimage
yes | sudo pamac remove genisoimage #Not sure it works or is needed in Manjaro, try it
inst xorriso

#Set Penguins Eggs to be loaded from a file instead of done manually.
sudo eggs dad -d --file $PWD/LastOSeggs.yaml




##### Copy Overlay Best Method (Doesn't have /opt/LastOS at all)

sudo mkdir -m a=rwx /Overlay

# 777 Everyone full access, 775 gives everyone read access only, root and owner get RWX
sudo cp -rf Overlays/* /Overlay
sudo chmod -R 775 /Overlay

#Copy the repaird Overlay to the root of the filesystem: the -a should be recursive and keep permissions etc
sudo cp -a /Overlay/* /

#Delete the Overlay folder now as we don't need it and I don't need to change the ownership of it below
sudo rm -r /Overlay

#--------------------------------------


#Try putting my own installer script over the top
sudo cp -f "./Overlays/usr/lib/penguins-eggs/assets/calamares/install-system.sh" "/usr/lib/penguins-eggs/assets/calamares/"

##Make sure LLStore folder has correct permissions:
## --- SECURITY FIX: Secure LLStore ---
#sudo chown -R root:lastos-users /opt/LastOS/LLStore
#sudo chmod -R 775 /opt/LastOS/LLStore
# ------------------------------------

#Clones Only the OS, no users kept
#sudo eggs produce --excludes static --release --script --noicon --links LastOS-ReadMe -n
# I removed '--links LastOS-ReadMe' as it was not right path or icon

eggs produce --theme $PWD/LastOSTheme --release --script --noicon -n

sudo BuildTools/Egg1-Bind.sh

#Copy the ISO_Overlay to ISO
echo Copying Overlay, wait...
#sudo cp -R ISO_Overlay/* /home/eggs/iso
sudo cp -R ISO_Overlay/* /home/eggs/mnt/iso

#Rename the ISO internal name from "-V3.0" and Linux To LastOSLinux
sudo grep -lZ '"-V3.0"' /home/eggs/bin/mkisofs | sudo xargs -0 sed -i 's|"-V3.0"|"LastOSLinux"|g'
sudo grep -lZ 'Linux' /home/eggs/bin/mkisofs | sudo xargs -0 sed -i 's|-V Linux|-V LastOSLinux|g'

#The scripts go to home/eggs/ovarium/


#Add the lastos-users group to calamares if it exists

# Configuration
FILE="/etc/calamares/modules/users.conf"
GROUP_NAME="lastos-users"

# 1. Ensure the group exists on the current system (for penguins-eggs)
if ! getent group "$GROUP_NAME" > /dev/null; then
    echo "Creating system group: $GROUP_NAME..."
    groupadd --system "$GROUP_NAME"
else
    echo "Group '$GROUP_NAME' already exists on the system."
fi

# 2. Check if the Calamares config exists
if [ ! -f "$FILE" ]; then
    echo "Error: $FILE not found. Is Calamares installed?"
    exit 1
fi

# 3. Create a backup before modifying
cp "$FILE" "${FILE}.bak"

# 4. Inject into users.conf if not already there
if grep -q "name: $GROUP_NAME" "$FILE"; then
    echo "Group '$GROUP_NAME' is already in $FILE. No changes made."
else
    echo "Updating $FILE..."
    
    # We target the 'dip' block specifically to maintain the list order
    # \s* handles potential leading whitespace variations
    sed -i '/- name: dip/,/must_exist: true/ s/must_exist: true/&\n  - name: lastos-users\n    must_exist: true/' "$FILE"

    echo "Update complete. Backup saved as ${FILE}.bak"
fi

##Theme Style (Doesn't work yet)
#mkdir -p /home/eggs/liveroot/etc/calamares/branding/LastOSTheme
#cp -f LastOSTheme/theme/calamares/branding/stylesheet.qss /home/eggs/liveroot/etc/calamares/branding/LastOSTheme/

#cp -f $PWD/LastOSTheme/theme/calamares/branding/stylesheet.qss /home/eggs/liveroot/etc/calamares/branding/LastOSTheme/

#cp -f LastOSTheme/theme/calamares/branding/branding.desc /home/eggs/liveroot/etc/calamares/branding/LastOSTheme/

#cp -f $PWD/LastOSTheme/theme/calamares/branding/branding.desc /home/eggs/liveroot/etc/calamares/branding/LastOSTheme/

# Configuration
FILE="/home/eggs/liveroot/etc/calamares/modules/users.conf"
GROUP_NAME="lastos-users"

# 1. Ensure the group exists on the current system (for penguins-eggs)
if ! getent group "$GROUP_NAME" > /dev/null; then
    echo "Creating system group: $GROUP_NAME..."
    groupadd --system "$GROUP_NAME"
else
    echo "Group '$GROUP_NAME' already exists on the system."
fi

# 2. Check if the Calamares config exists
if [ ! -f "$FILE" ]; then
    echo "Error: $FILE not found. Is Calamares installed?"
    exit 1
fi

# 3. Create a backup before modifying
cp "$FILE" "${FILE}.bak"

# 4. Inject into users.conf if not already there
if grep -q "name: $GROUP_NAME" "$FILE"; then
    echo "Group '$GROUP_NAME' is already in $FILE. No changes made."
else
    echo "Updating $FILE..."
    
    # We target the 'dip' block specifically to maintain the list order
    # \s* handles potential leading whitespace variations
    sed -i '/- name: dip/,/must_exist: true/ s/must_exist: true/&\n  - name: lastos-users\n    must_exist: true/' "$FILE"

    echo "Update complete. Backup saved as ${FILE}.bak"
fi








#Make SquishFS (Compressed OS image)
echo Make SquashFS...
sudo BuildTools/Egg3-mksquishfs.sh

sudo BuildTools/Egg4-UnBind.sh

#Make ISO and open folder to it
echo Make ISO...
sudo BuildTools/Egg5-Make_ISO.sh

#Open the folder as root (ISO is only avaialble to root user) The & at the end should hopefully exist the terminal and keep root nemo running.
#sudo BuildTools/Egg2-Open_Mount_as_Root.sh

UserHome=$HOME ; mv -f /home/eggs/mnt/*.iso $UserHome
UserHome=$HOME ; cd $UserHome ;chown $(logname):$(id -gn $SUDO_USER) *.iso
sudo chmod 777 $HOME/*.iso

#Cleanup this build once have the ISO
sudo rm -f -r /home/eggs

#Open to Folder (Will open as root due to the script being root so move to other script
#nemo $HOME &

exit 0