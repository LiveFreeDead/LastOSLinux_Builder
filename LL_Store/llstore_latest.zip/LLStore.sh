#!/bin/bash

env GDK_BACKEND=x11 ./llstore


